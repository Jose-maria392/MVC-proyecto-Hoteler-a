const carousel = document.getElementById('carousel');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const itemWidth = 280 + 28; // 280px ancho de tarjeta + 28px gap

  // Botón izquierdo: mover a la izquierda
  prevBtn.addEventListener('click', () => {
    carousel.scrollBy({
      left: -itemWidth,
      behavior: 'smooth'
    });
  });

  // Botón derecho: mover a la derecha
  nextBtn.addEventListener('click', () => {
    carousel.scrollBy({
      left: itemWidth,
      behavior: 'smooth'
    });
  });

  // Hacer clic en cualquier parte de la tarjeta redirige al href del .card-button
  document.querySelectorAll('.carousel-item').forEach(item => {
    const link = item.querySelector('.card-button');
    if (link) {
      item.addEventListener('click', (e) => {
        // Si el clic fue justo en el botón, no repetimos la acción
        if (e.target.closest('.card-button')) return;
        e.preventDefault();
        window.location.href = link.href;  // redirige al archivo HTML
      });
    }
  });
