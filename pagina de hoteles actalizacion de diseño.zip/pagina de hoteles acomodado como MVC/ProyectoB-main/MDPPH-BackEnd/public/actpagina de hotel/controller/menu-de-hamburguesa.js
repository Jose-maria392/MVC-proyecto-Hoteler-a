const menuToggleBtn = document.getElementById('menuToggleBtn');
const closeMenuBtn = document.getElementById('closeMenuBtn');
const hotelMenuPanel = document.getElementById('hotelMenuPanel');
const hotelMenuOverlay = document.getElementById('hotelMenuOverlay');
const settingsMenuBtn = document.getElementById('settingsMenuBtn');
const loginSubBtn = document.getElementById('loginSubBtn');

function openMenu() {
    hotelMenuPanel.classList.add('open');
    hotelMenuOverlay.classList.add('open');
    hotelMenuPanel.setAttribute('aria-hidden', 'false');
    menuToggleBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
}

function closeMenu() {
    hotelMenuPanel.classList.remove('open');
    hotelMenuOverlay.classList.remove('open');
    hotelMenuPanel.setAttribute('aria-hidden', 'true');
    menuToggleBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    loginSubBtn.style.display = 'none';
}

menuToggleBtn.addEventListener('click', () => {
    hotelMenuPanel.classList.contains('open') ? closeMenu() : openMenu();
});

closeMenuBtn.addEventListener('click', closeMenu);
hotelMenuOverlay.addEventListener('click', closeMenu);

settingsMenuBtn.addEventListener('click', () => {
    loginSubBtn.style.display = (loginSubBtn.style.display === 'flex' || loginSubBtn.style.display === 'block') ? 'none' : 'flex';
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeMenu();
});

