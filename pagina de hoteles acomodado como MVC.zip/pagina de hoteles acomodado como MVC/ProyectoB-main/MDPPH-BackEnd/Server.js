const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
// Puerto
const path = require('path');
require('dotenv').config({ path: './Config/.env' }); // Carga .env desde Config/

const helmet = require('helmet');
const xss = require('xss-clean');
const app = express();

// Conectar a MongoDB
const connectDB = require('./Config/MongoDB');

// Helmet - Armadura para el servidor
// app.use(helmet()); // Desactivarlo para cambios
app.set('trust proxy', 1);

// Si no estamos en el entorno de pruebas de Jest, conectamos a la DB real.
if (!process.env.JEST_WORKER_ID) {
    connectDB();
}

// CORS Middleware - Permite solo solicitudes desde frontend
const corsOptions = {
    // URL para el servidor la URL o en formato local '*'
    // origin: '*',
    origin: 'https://summital-rosamond-driverless.ngrok-free.dev', // Permitir todas las solicitudes
    optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

// Middlewares
app.use(express.json()); // Para parsear JSON
//Limpieza de XSS (Después de leer el JSON pero antes de las rutas)
app.use(xss());
app.use(express.static(path.join(__dirname, 'public', 'actpagina de hotel'))); // Sirve archivos estáticos desde 'public/'

// Conectar a MongoDB
/*const connectDB = require('./Config/MongoDB');
connectDB();*/

// Rutas (comenta las que no uses por ahora)
app.use('/api/auth', require('./Modules/Auth/authRoutes'));
//app.use('/api/client', require('./Modules/Client/clientRoutes'));
app.use('/api/user', require('./Modules/User/userRoutes'));

// Ruta para reservaciones (la única activa por ahora)
app.use('/api/reservation', require('./Modules/Reservation/ReservationRoutes'));

const PORT = process.env.PORT || 5000;

// Route to serve the frontend index.html on root '/'
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'actpagina de hotel', 'index.html'));
});

if (!process.env.JEST_WORKER_ID) {
  app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));
}

module.exports = app;
