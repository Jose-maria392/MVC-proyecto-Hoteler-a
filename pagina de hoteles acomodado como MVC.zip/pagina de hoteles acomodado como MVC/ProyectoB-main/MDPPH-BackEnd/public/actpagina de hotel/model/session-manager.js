class SessionManager {
    constructor() {
        this.init();
    }

    init() {
        this.loadUser();
        this.bindEvents();
        this.updateUI();
    }

    loadUser() {
        const userData = localStorage.getItem('userSession');
        if (userData) {
            this.user = JSON.parse(userData);
        }
    }

    login(username, email) {
        this.user = {
            username: username || 'Usuario',
            email: email,
            avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(username || 'U')}&size=64&background=4F46E5&color=fff`
        };
        localStorage.setItem('userSession', JSON.stringify(this.user));
        this.updateUI();
    }

    logout() {
        // Al salir cierra la sesion y elimina el token
        localStorage.removeItem('userSession');
        localStorage.removeItem('token');

        this.user = null;
        this.hidePanel();
        this.updateUI();

        window.location.replace('../view/login.html');
    }

    isLoggedIn() {
        return !!this.user;
    }

    // Agregar estos métodos a la clase SessionManager
    setupBackdropClick() {
        // Panel de usuario
        const panel = document.getElementById('userPanel');
        if (panel) {
            panel.addEventListener('click', (e) => {
                // Si haces clic FUERA del contenido del panel, cerrar
                if (e.target === panel) {
                    this.hidePanel();
                }
            });
        }
    
        // Modal de confirmación de logout
        const logoutModal = document.getElementById('logoutConfirmModal');
        if (logoutModal) {
            logoutModal.addEventListener('click', (e) => {
                // Si haces clic FUERA del contenido del modal, cerrar
                if (e.target === logoutModal) {
                    this.hideLogoutConfirm();
                }
            });
        }
    }

    bindEvents() {
        const toggleBtn = document.getElementById('sessionToggleBtn');
        const panel = document.getElementById('userPanel');
        const logoutBtn = document.getElementById('logoutBtn');
        const settingsBtn = document.getElementById('userSettingsBtn');
        // Eventos del modal de confirmación de logout
        const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
        const cancelLogoutBtn = document.getElementById('cancelLogoutBtn');

        if (toggleBtn) {
            toggleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (this.isLoggedIn()) {
                    this.showPanel();
                } else {
                    window.location.href = '../view/login.html';
                }
            });
        }

        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.showLogoutConfirm();
            });
        }

        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => {
                alert('Panel de ajustes - Próximamente');
            });
        }

        if (confirmLogoutBtn) {
            confirmLogoutBtn.addEventListener('click', () => {
                this.logout();
                this.hideLogoutConfirm();
            });
        }

        if (cancelLogoutBtn) {
            cancelLogoutBtn.addEventListener('click', () => {
                this.hideLogoutConfirm();
            });
        }

        // cerrar con clic fuera
        this.setupBackdropClick();

        // Cerrar panel
        //document.addEventListener('click', (e) => {
            //if (panel && panel.style.display === 'flex' &&
                //!panel.contains(e.target) &&
                //!toggleBtn?.contains(e.target)) {
                //this.hidePanel();
            //}
        //});

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && panel?.style.display === 'flex') {
                this.hidePanel();
            }
        });
    }

    // Nuevo método para mostrar modal de confirmación
    showLogoutConfirm() {
        const modal = document.getElementById('logoutConfirmModal');
        if (modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    }

    // Nuevo método para cerrar modal
    hideLogoutConfirm() {
        const modal = document.getElementById('logoutConfirmModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }

    showPanel() {
        const panel = document.getElementById('userPanel');
        if (panel) {
            panel.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    }

    hidePanel() {
        const panel = document.getElementById('userPanel');
        if (panel) {
            panel.style.display = 'none';
            document.body.style.overflow = '';
        }
    }

    updateUI() {
        const label = document.getElementById('sessionLabel');
        const nameEl = document.getElementById('userNameDisplay');
        const emailEl = document.getElementById('userEmailDisplay');
        const avatarEl = document.getElementById('userAvatarImg');

        if (this.isLoggedIn() && this.user) {
            const nombreAMostrar = this.user.username || this.user.nombre || 'Usuario';
            if (label) label.textContent = nombreAMostrar.split(' ')[0];
            if (nameEl) nameEl.textContent = nombreAMostrar;
            if (emailEl) emailEl.textContent = this.user.email;
            if (avatarEl) avatarEl.src = this.user.avatar;
        } else {
            if (label) label.textContent = 'Iniciar Sesión';
        }
    }
}

// Inicializar
const sessionManager = new SessionManager();

/*document.addEventListener('DOMContentLoaded', () => {
    window.sessionManager = new SessionManager();
});*/