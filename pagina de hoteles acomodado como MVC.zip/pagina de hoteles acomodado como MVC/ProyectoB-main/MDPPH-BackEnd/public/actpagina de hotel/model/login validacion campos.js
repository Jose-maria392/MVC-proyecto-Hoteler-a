// Funcion para no retornar al login
(function () {
    const token = localStorage.getItem('token');
    if (token) {
        // Si ya hay sesión, no lo deja estar en el Login
        window.location.replace('./');
    }
})();

// Evitamos que se regrese y recargando manager
window.addEventListener('pageshow', function (event) {
    if (event.persisted) {
        window.location.reload();
    }
});

// =======================================================
// === FUNCIONES PARA MODALES DE ALERTA (LOGIN ESPECÍFICO) ===
// =======================================================

// Función para mostrar modal de alerta (específica para login.html)
function showLoginAlert(title, message, isSuccess = false) {
    const modal = document.getElementById('login-alert-modal');
    if (!modal) return;

    const titleEl = document.getElementById('alert-modal-title');
    const messageEl = document.getElementById('alert-modal-message');
    const okBtn = document.getElementById('alert-modal-ok');
    
    // Configurar contenido
    titleEl.textContent = title;
    messageEl.textContent = message;
    
    // Estilo según tipo (éxito/error)
    if (isSuccess) {
        titleEl.style.color = '#10b981';
        messageEl.style.color = '#10b981';
    } else {
        titleEl.style.color = '#ef4444';
        messageEl.style.color = '#ef4444';
    }
    
    // Mostrar modal
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Evita scroll de fondo
    
    // Cerrar al hacer clic en OK
    const closeModal = () => {
        modal.style.display = 'none';
        document.body.style.overflow = '';
        //okBtn.removeEventListener('click', closeModal);
    };
    
    okBtn.onclick = closeModal;
    //okBtn.addEventListener('click', closeModal);
    
    document.onkeydown = (e) => {
        if (e.key === 'Escape') closeModal();
    };
    // Cerrar con ESC
    //const handleEsc = (e) => {
        //if (e.key === 'Escape') {
            //closeModal();
            //document.removeEventListener('keydown', handleEsc);
        //}
    //};
    //document.addEventListener('keydown', handleEsc);
}

// Función para cerrar modal con clic fuera
function setupModalBackdrop() {
    const modals = ['login-alert-modal', 'register-modal', 'recover-modal-step1', 'recover-modal-step2'];
    
    modals.forEach(id => {
        const modal = document.getElementById(id);
        if (modal){
            modal.addEventListener('click', (e) => {
                if (e.target === modal){
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
        }
    });
}

// ✅ ABRIR MODALES SOLO AL HACER CLIC (NO al cargar)
function initModalOpeners() {
    // Registro
    const openRegister = document.getElementById('open-register-modal');
    if (openRegister) {
        openRegister.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('register-modal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });
    }
    
    // Recuperación
    const openRecover = document.getElementById('open-recover-modal');
    if (openRecover) {
        openRecover.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('recover-modal-step1').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });
    }
}

// ✅ INICIALIZACIÓN SEGURA (DOMContentLoaded)
document.addEventListener('DOMContentLoaded', () => {
    setupModalBackdrop();
    initModalOpeners();
    // NO hay código que active modales aquí
});

// Inicializar backdrop para todas las modales al cargar
document.addEventListener('DOMContentLoaded', () => {
    setupModalBackdrop('login-alert-modal');
    setupModalBackdrop('register-modal');
    setupModalBackdrop('recover-modal-step1');
    setupModalBackdrop('recover-modal-step2');
});

// =======================================================
// === 1. LÓGICA PARA EL FORMULARIO DE INICIO DE SESIÓN (LOGIN) ===
// =======================================================

// A. Obtener elementos del DOM para LOGIN
const loginForm = document.getElementById('loginForm');
const loginEmailInput = document.getElementById('email');
const loginPasswordInput = document.getElementById('password');
const loginEmailError = document.getElementById('emailError');
const loginPasswordError = document.getElementById('passwordError');

// Función para validar el formato básico de un email (usada por ambos)
function isValidEmail(email) {
    // Regex simple para verificar formato básico de correo (ej: a@b.c)
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// B. Función principal de validación para LOGIN
function validateLoginForm(event) {
    // Detiene el envío normal del formulario para que JS haga la validación
    event.preventDefault();

    let isValid = true;

    // Obtener contenedor de aviso general
    const loginFormAlert = document.getElementById('loginFormAlert');
    if (loginFormAlert) { loginFormAlert.style.display = 'none'; loginFormAlert.textContent = ''; }

    // --- VALIDACIÓN DE CORREO ELECTRÓNICO (LOGIN) ---
    const emailValue = loginEmailInput.value.trim();
    loginEmailInput.classList.remove('input-error');
    loginEmailError.textContent = '';

    if (emailValue === '' || !isValidEmail(emailValue)) {
        loginEmailInput.classList.add('input-error');
        loginEmailError.textContent = 'Por favor introduzca un correo válido';
        isValid = false;
    }

    // --- VALIDACIÓN DE CONTRASEÑA (LOGIN) ---
    const passwordValue = loginPasswordInput.value;
    loginPasswordInput.classList.remove('input-error');
    loginPasswordError.textContent = '';

    // Condición: La contraseña NO tiene 8 dígitos
    if (passwordValue.length !== 8) {
        loginPasswordInput.classList.add('input-error');
        loginPasswordError.textContent = 'Por favor introduzca una contraseña de 8 dígitos';
        isValid = false;
    }

    // --- ENVÍO DEL FORMULARIO (LOGIN) ---
    if (isValid) {
        const loginData = {
            email: emailValue,
            password: passwordValue
        };

        // Aviso de errores
        const loginFormAlert = document.getElementById('loginFormAlert');
        // URL para el servidor
        fetch('https://summital-rosamond-driverless.ngrok-free.dev/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginData)
        })
            .then(async (response) => {
                // Si el servidor responde 401, el token expiró o es inválido
                if (response.status === 401) {
                    localStorage.removeItem('token'); // Limpiamos por seguridad
                    //if (loginFormAlert) {
                        //loginFormAlert.style.display = 'block';
                        //loginFormAlert.textContent = '❌ Correo o contraseña incorrectos. Verifica tus datos.';
                        // window.location.href = './';
                    //}
                    showLoginAlert('Error al Iniciar Sesión', '❌ Correo o Contraseña incorrectos. Verifica tus datos.', false);
                    return;
                }
                const data = await response.json();

                if (!response.ok) {
                    // Si el backend rechaza el login, lanzamos el mensaje que viene del server
                    throw new Error('Correo o contraseña incorrectos. Por favor, inténtalo de nuevo.');
                }

                // Exito en la sesion y se redirige
                if (data.token) {
                    localStorage.setItem('token', data.token);
                    const userSession = {
                        username: data.user.nombre, // Sacamos el nombre real de tu base de datos
                        email: data.user.email,
                        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.user.nombre)}&background=4F46E5&color=fff`
                    };
                    // Guarda el objeto completo para SessionManager
                    localStorage.setItem('userSession', JSON.stringify(userSession));

                    // Mensaje de cargar en un futuro o una pantalla
                    window.location.replace('./');
                }
            })
            .catch(() => {
                // Mensaje de error para el servidor
                //if (loginFormAlert) {
                    //loginFormAlert.style.display = 'block'; // Lo hacemos visible
                    //loginFormAlert.style.color = '#e11d48'; // Color rojo
                    //loginFormAlert.textContent = 'Lo sentimos, hubo un problema al conectar. Inténtalo más tarde.';
                //}
                showLoginAlert('Error de Conexión', 'Lo sentimos, hubo un problema de Conexión al Servidor. Inténtalo más tarde.', false);
            });
    }
}

// C. Asignar el evento al formulario de LOGIN
if (loginForm) {
    loginForm.addEventListener('submit', validateLoginForm);
}


// ========================================================
// === 2. LÓGICA PARA EL FORMULARIO DE REGISTRO (REGISTER) ===
// ========================================================

// A. Obtener elementos del DOM para REGISTRO
const registerForm = document.getElementById('registerForm');

// Usamos nombres únicos para evitar conflictos con las variables de LOGIN
const registerUsernameInput = document.getElementById('username-reg');
const registerEmailInput = document.getElementById('email-reg');
const registerPasswordInput = document.getElementById('password-reg');

const registerUsernameError = document.getElementById('usernameError');
// Asumiendo que los mensajes de error para registro tienen IDs diferentes o son hijos directos en la estructura HTML anterior
// Si tienen los mismos IDs, solo se actualizará el último elemento encontrado. 
// Para un ejemplo robusto, se usa el patrón que asignaste al formulario de registro.
const registerEmailError = document.getElementById('emailError-reg') || document.getElementById('emailErrordos');
const registerPasswordError = document.getElementById('passwordError-reg') || document.getElementById('passwordErrordos');


// B. Función principal para validar el formulario de REGISTRO
function validateRegisterForm() {
    let isValid = true;

    // --- 1. Validar Nombre de Usuario (REGISTRO) ---
    if (registerUsernameInput && registerUsernameInput.value.trim() === '') {
        registerUsernameInput.classList.add('input-error');
        if (registerUsernameError) registerUsernameError.textContent = 'Por favor introduzca un nombre de usuario';
        isValid = false;
    } else if (registerUsernameInput) {
        registerUsernameInput.classList.remove('input-error');
        if (registerUsernameError) registerUsernameError.textContent = '';
    }

    // --- 2. Validar Correo Electrónico (REGISTRO) ---
    if (registerEmailInput && !isValidEmail(registerEmailInput.value)) {
        registerEmailInput.classList.add('input-error');
        if (registerEmailError) registerEmailError.textContent = 'Por favor introduzca un correo valido';
        isValid = false;
    } else if (registerEmailInput) {
        registerEmailInput.classList.remove('input-error');
        if (registerEmailError) registerEmailError.textContent = '';
    }

    // --- 3. Validar Contraseña (8 dígitos exactos) (REGISTRO) ---
    if (registerPasswordInput && registerPasswordInput.value.length !== 8) {
        registerPasswordInput.classList.add('input-error');
        if (registerPasswordError) registerPasswordError.textContent = 'Por favor cree una contraseña de 8 dígitos';
        isValid = false;
    } else if (registerPasswordInput) {
        registerPasswordInput.classList.remove('input-error');
        if (registerPasswordError) registerPasswordError.textContent = '';
    }

    return isValid;
}

// C. Escuchamos el evento de envío del formulario de REGISTRO
if (registerForm) {
    registerForm.addEventListener('submit', function (event) {
        // Evita que el formulario se envíe por defecto
        event.preventDefault();
        // Ejecuta la validación
        const registerFormAlert = document.getElementById('registerFormAlert');
        if (registerFormAlert) { registerFormAlert.style.display = 'none'; registerFormAlert.textContent = ''; }

        if (validateRegisterForm()) {
            // Si todos los campos son válidos, redirige a index.html
            ////alert('Formulario de Registro validado con éxito. Redireccionando a index.html...');
            // GUARDAR SESIÓN Y REDIRIGIR
            const nuevoUsuario = {
                nombre: registerUsernameInput.value.trim(),
                email: registerEmailInput.value.trim(),
                password: registerPasswordInput.value // Tu validación ya asegura que son 8 dígitos
            };

            const registerFormAlert = document.getElementById('registerFormAlert');

            // URL para el servidor
            fetch('https://summital-rosamond-driverless.ngrok-free.dev/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(nuevoUsuario)
            })
                .then(async (response) => {
                    const data = await response.json();

                    if (response.ok) {
                        if (data.token && data.user) {
                            localStorage.setItem('token', data.token);
                            localStorage.setItem('userSession', JSON.stringify({
                                username: data.user.nombre,
                                email: data.user.email,
                                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.user.nombre)}&background=4F46E5&color=fff`
                            }));
                        }

                        showLoginAlert('✅ Registro Exitoso', 'Bienvenido.', true);
                        // Usuario registrado exitosamente
                        //if (registerFormAlert) {
                            //registerFormAlert.style.display = 'block';
                            //registerFormAlert.style.color = '#10b981'; // Color
                            //registerFormAlert.textContent = '✅ Cuenta creada con éxito. Ya puedes iniciar sesión.';
                        //}

                        // Esperamos un segundo para que el usuario lea el mensaje y redirigimos
                        setTimeout(() => {
                            window.location.replace('./');
                        }, 1500);
                    } else {
                        // Error si el correo ya está registrado
                        throw new Error(data.message || 'No se pudo completar el registro. Intenta con otro correo.');
                    }
                })
                .catch((error) => {
                    // Error en el servidor
                    //if (registerFormAlert) {
                        //registerFormAlert.style.display = 'block';
                        //registerFormAlert.style.color = '#e11d48'; // Color
                        //registerFormAlert.textContent = '❌ ' + (error.message || 'Hubo un problema de conexión. Inténtalo más tarde.');
                    //}
                    showLoginAlert('Error de Conexón.', '❌ Error de Conexión al Servidor. Intentelo mas tarde.', false);
                });
        } else {
            // Mostrar aviso general si falla
            //if (registerFormAlert) {
                //registerFormAlert.style.display = 'block';
                //registerFormAlert.style.color = '#e11d48'; // Color
                //registerFormAlert.textContent = 'Completa los campos requeridos marcados.';
            //}
            showLoginAlert('Error en los Campos', 'Completa los campos requeridos marcados.', false);
        }
    });

    // Opcional: Validar al perder el foco (Blur event) para mejor UX
    if (registerUsernameInput) registerUsernameInput.addEventListener('blur', validateRegisterForm);
    if (registerEmailInput) registerEmailInput.addEventListener('blur', validateRegisterForm);
    if (registerPasswordInput) registerPasswordInput.addEventListener('blur', validateRegisterForm);
}

// ==============================================
// 3. FLUJO DE RECUPERACIÓN (ENVÍO Y VERIFICACIÓN)
//    - Soporta MODO_REAL si el desarrollador establece endpoints en RECOVERY_API
//    - Si no hay endpoints configurados, cae en MODO_SIMULADO (genera código localmente)
// ==============================================

// Configuración: sustituye las URLs por tus endpoints reales si tienes backend
const RECOVERY_API = {
    // Si estás ejecutando el servidor local (recovery-server), usa las rutas por defecto:
    // URL del servidor
    send: 'https://summital-rosamond-driverless.ngrok-free.dev/api/auth/forgot-password',
    verify: 'https://summital-rosamond-driverless.ngrok-free.dev/api/auth/verify-code'
};

// Elementos del DOM para recuperación
const recoverStep1 = document.getElementById('recover-modal-step1');
const recoverStep2 = document.getElementById('recover-modal-step2');
const goToStep2Btn = document.getElementById('go-to-step2');
const closeRecoverStep1Btn = document.getElementById('close-recover-modal-step1');
const backToStep1Btn = document.getElementById('back-to-step1');
const recoverSentMessage = document.getElementById('recoverSentMessage');
const recoverFormStep2 = document.getElementById('recoverFormStep2');
const emailRecoverInput = document.getElementById('email-recover');
const codeRecoverInput = document.getElementById('code-recover');
const emailErrorSpan = document.getElementById('email-recover-error');
const codeExpiredModal = document.getElementById('code-expired-modal');
const confirmCodeExpiredBtn = document.getElementById('confirm-code-expired');

// Funcion para validar email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Función para marcar campo como inválido
function markFieldInvalid(field, errorMsg, errorSpan) {
    field.style.borderColor = 'red';
    field.style.boxShadow = '0 0 5px rgba(255,0,0,0.3)';
    if (errorSpan) {
        errorSpan.textContent = errorMsg;
        errorSpan.style.display = 'block';
    }
}

// Función para marcar campo como válido
function markFieldValid(field, errorSpan) {
    field.style.borderColor = '#28a745';
    field.style.boxShadow = '0 0 5px rgba(40,167,69,0.3)';
    if (errorSpan) {
        errorSpan.style.display = 'none';
    }
}

// simulacion de envio de codigo
function simulateSendCode(email) {
    return new Promise((resolve) => {
        // Genera un código de 4 dígitos y lo guarda temporalmente en la ventana (solo para pruebas)
        const code = Math.floor(1000 + Math.random() * 9000).toString();
        window.__recoverCode = code;
        console.info('Simulated recover code for', email, ':', code);
        setTimeout(() => resolve({ ok: true, simulated: true, code }), 700);
    });
}

//simulacion de verificacion de codigo
function simulateVerifyCode(email, code) {
    return new Promise((resolve) => {
        const ok = (window.__recoverCode && String(code).trim() === String(window.__recoverCode));
        setTimeout(() => resolve({ ok }), 300);
    });
}

async function sendRecoveryCode(email) {
    if (!email) throw new Error('Email requerido');
    // Si el endpoint real está configurado, usar fetch
    try {
        const res = await fetch(RECOVERY_API.send, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        const data = await res.json();
        return { ok: res.ok, data };
    } catch (err) {
        return { ok: false, error: 'Error de conexión con el servidor.' };
    }
}

async function verifyRecoveryCode(email, code) {
    if (!email || !code) return { ok: false };
    try {
        const res = await fetch(RECOVERY_API.verify, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, code })
        });
        const data = await res.json();
        return { ok: res.ok, data };
    } catch (err) {
        return { ok: false, error: 'Error al verificar el código.' };
    }
}

// Helper: mostrar/ocultar modals simple
//function showModal(el) { if (!el) return; el.style.display = 'flex'; }
//function hideModal(el) { if (!el) return; el.style.display = 'none'; }
function showModal(el) { if (el) el.style.display = 'flex'; }
function hideModal(el) { if (el) el.style.display = 'none'; }

// Validación del email en tiempo real
if (emailRecoverInput) {
    emailRecoverInput.addEventListener('input', () => {
        const email = emailRecoverInput.value.trim();
        if (email && !isValidEmail(email)) {
            markFieldInvalid(emailRecoverInput, 'Por favor ingrese un correo válido', emailErrorSpan);
        } else if (email) {
            markFieldValid(emailRecoverInput, emailErrorSpan);
        } else {
            emailRecoverInput.style.borderColor = '';
            emailRecoverInput.style.boxShadow = '';
            if (emailErrorSpan) emailErrorSpan.style.display = 'none';
        }
    });
}

// Botón: ir a paso 2 (envía código) - VALIDACIÓN VISUAL
if (goToStep2Btn) {
    goToStep2Btn.addEventListener('click', async () => {
        const email = emailRecoverInput ? emailRecoverInput.value.trim() : '';

        // Validación visual del email
        if (!email) {
            markFieldInvalid(emailRecoverInput, 'El correo es requerido', emailErrorSpan);
            return;
        }

        if (!isValidEmail(email)) {
            markFieldInvalid(emailRecoverInput, 'Por favor ingrese un correo válido', emailErrorSpan);
            return;
        }

        markFieldValid(emailRecoverInput, emailErrorSpan);

        // Indica al usuario que se está enviando
        if (recoverSentMessage) {
            recoverSentMessage.style.display = 'block';
            recoverSentMessage.style.color = 'blue';
            recoverSentMessage.textContent = 'Enviando código a tu correo...';
        }

        // Llamada al backend
        const result = await simulateSendCode(email);

        if (result.ok) {
            // Mostrar código por 15 segundos
            if (recoverSentMessage) {
                recoverSentMessage.style.color = 'green';
                recoverSentMessage.textContent = `Código enviado. Revisa tu bandeja de entrada.`;
            }
            hideModal(recoverStep1);
            showModal(recoverStep2);
        } else {
            markFieldInvalid(emailRecoverInput, result.data?.message || 'Error al enviar el código', emailErrorSpan);
            if (recoverSentMessage) recoverSentMessage.style.display = 'none';
        }
    });
}

// Volver al paso 1
if (backToStep1Btn) {
    backToStep1Btn.addEventListener('click', () => {
        hideModal(recoverStep2);
        showModal(recoverStep1);
        // Resetear estado visual
        if (emailRecoverInput) {
            emailRecoverInput.style.borderColor = '';
            emailRecoverInput.style.boxShadow = '';
        }
        if (emailErrorSpan) emailErrorSpan.style.display = 'none';
        if (recoverSentMessage) recoverSentMessage.style.display = 'none';
    });
}

// Cerrar paso 1
if (closeRecoverStep1Btn) {
    closeRecoverStep1Btn.addEventListener('click', () => {
        hideModal(recoverStep1);
        // Resetear estado visual
        if (emailRecoverInput) {
            emailRecoverInput.style.borderColor = '';
            emailRecoverInput.style.boxShadow = '';
            emailRecoverInput.value = '';
        }
        if (emailErrorSpan) emailErrorSpan.style.display = 'none';
        if (recoverSentMessage) recoverSentMessage.style.display = 'none';
    });
}

// Envío del formulario de verificación (paso 2)
if (recoverFormStep2) {
    recoverFormStep2.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = emailRecoverInput ? emailRecoverInput.value.trim() : '';
        const code = codeRecoverInput ? codeRecoverInput.value.trim() : '';
        const codeErrorSpan = document.getElementById('code-recover-error');

        if (!code || code.length !== 4) {
            //alert('Introduce el código de 4 dígitos recibido.');
            markFieldInvalid(codeRecoverInput, 'Introduce el codigo de 4 dígitos recibido.', codeErrorSpan);
            return;
        }

        // verificar si exite codigo generado
        if (!window.__recoverCode) {
            markFieldInvalid(codeRecoverInput, 'No se ha enviado un codigo aún. por favor solicite el codigo primero.', codeErrorSpan);
            return;
        }

        const verification = await simulateVerifyCode(email, code);

        if (verification.ok) {
            // GUARDAR SESIÓN Y REDIRIGIR
            const userData = verification.data.user;
            const token = verification.data.token;

            localStorage.setItem('token', token);
            localStorage.setItem('userSession', JSON.stringify({
                username: userData.nombre,
                email: userData.email,
                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(userData.nombre)}&background=4F46E5&color=fff`
            }));

            hideModal(recoverStep2);
            window.location.replace('./');
        } else {
            // codigo incorrecto
            markFieldInvalid(codeRecoverInput, verification.data?.message || 'Código incorrecto', codeErrorSpan);
        }
    });
}

// Validación en tiempo real para el campo de código
if (codeRecoverInput) {
    codeRecoverInput.addEventListener('input', () => {
        const code = codeRecoverInput.value.trim();
        const codeErrorSpan = document.getElementById('code-recover-error');

        if (code && code.length !== 4) {
            markFieldInvalid(codeRecoverInput, 'El código debe tener 4 dígitos.', codeErrorSpan);
        } else if (code) {
            markFieldValid(codeRecoverInput, codeErrorSpan);
        } else {
            codeRecoverInput.style.borderColor = '';
            codeRecoverInput.style.boxShadow = '';
            if (codeErrorSpan) codeErrorSpan.style.display = 'none';
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Limpiamos los rastros para que el formulario funcione de cero.
    if (localStorage.getItem('token')) {
        console.log("Sesión previa detectada en Login. Limpiando para nuevo acceso...");
    }
});

// Confirmar modal de código expirado
//if (confirmCodeExpiredBtn) {
//confirmCodeExpiredBtn.addEventListener('click', () => {
// hideModal(codeExpiredModal);
//});
//}

// Botón: ir a paso 2 (envía código)
//if (goToStep2Btn) {
//goToStep2Btn.addEventListener('click', async () => {
//const email = emailRecoverInput ? emailRecoverInput.value.trim() : '';
//if (!email || !isValidEmail(email)) {
////alert('Introduce un correo válido para recuperar la contraseña.');
// return;
//  }

// Indica al usuario que se está enviando
// if (recoverSentMessage) { recoverSentMessage.style.display = 'block'; recoverSentMessage.style.color = 'black'; recoverSentMessage.textContent = 'Enviando código...'; }

//const result = await sendRecoveryCode(email);

//if (result && result.ok) {
// If backend indicates simulated mode and returns the code, show it clearly (developer/local mode)
// if (result.simulated && result.code) {
// if (recoverSentMessage) {
// recoverSentMessage.style.display = 'block';
// recoverSentMessage.style.color = 'green';
// recoverSentMessage.textContent = `Código enviado (simulado): ${result.code} — úsalo para verificar.`;
//  }
//} else {
//  if (recoverSentMessage) { recoverSentMessage.style.display = 'block'; recoverSentMessage.style.color = 'green'; recoverSentMessage.textContent = 'Código enviado. '; } //Revisa tu correo (o SMS).
// }
// Mostrar paso 2
// hideModal(recoverStep1);
// showModal(recoverStep2);
// } else {
// const msg = (result && result.error) ? result.error : 'Error al enviar el código. Intente de nuevo.';
// if (recoverSentMessage) { recoverSentMessage.style.display = 'block'; recoverSentMessage.style.color = 'red'; recoverSentMessage.textContent = msg; }
// }
//  });
//}

// Volver al paso 1
//if (backToStep1Btn) {
// backToStep1Btn.addEventListener('click', () => {
// hideModal(recoverStep2);
//showModal(recoverStep1);
//});
//}

// Cerrar paso 1 (botón 'Atrás')
//if (closeRecoverStep1Btn) {
//closeRecoverStep1Btn.addEventListener('click', () => hideModal(recoverStep1));
//}

// Envío del formulario de verificación (paso 2)
//if (recoverFormStep2) {
// recoverFormStep2.addEventListener('submit', async (e) => {
// e.preventDefault();
// const email = emailRecoverInput ? emailRecoverInput.value.trim() : '';
// const code = codeRecoverInput ? codeRecoverInput.value.trim() : '';
// if (!code || code.length < 3) {
// alert('Introduce el código de 4 dígitos recibido.');
// return;
// }

//const verification = await verifyRecoveryCode(email, code);
//if (verification && verification.ok) {
////alert('Código verificado. Ahora puedes restablecer tu contraseña. (Simulado)');
// Aquí puedes redirigir al formulario de cambio de contraseña o permitir reset
//hideModal(recoverStep2);
// window.location.href = './';
//} else {
// alert('Código incorrecto o expirado. Verifica e intenta de nuevo.');
// }
//});
//}