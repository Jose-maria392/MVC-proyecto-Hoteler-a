/* maps_osm.js
   Crea mapas Leaflet usando OpenStreetMap.
   - Si el contenedor tiene `data-lat` y `data-lng` usa esas coordenadas.
   - Si tiene `data-address` se geocodifica con Nominatim (limit=1).
   Inserta un marcador en la posición encontrada.
   Aviso: respeta la política de uso de Nominatim. Para producción usa un servicio con clave.
*/
(function(){
  'use strict';

  async function geocode(address){
    const url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(address);
    const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if(!res.ok) throw new Error('Geocoding failed: ' + res.status);
    const data = await res.json();
    if(!data || !data[0]) return null;
    return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
  }

  function createMap(container, lat, lon, zoom){
    zoom = zoom || 15;
    if(!container.style.height) container.style.height = '300px';
    const map = L.map(container).setView([lat, lon], zoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    L.marker([lat, lon]).addTo(map);
    return map;
  }

  async function initMaps(){
    const nodes = document.querySelectorAll('.osm-map');
    nodes.forEach(function(node){
      (async function(){
        const latAttr = node.getAttribute('data-lat');
        const lngAttr = node.getAttribute('data-lng');
        const zoomAttr = parseInt(node.getAttribute('data-zoom') || '15', 10);

        if(latAttr && lngAttr){
          const map = createMap(node, parseFloat(latAttr), parseFloat(lngAttr), zoomAttr);
          // ensure correct rendering if container was hidden or styled
          setTimeout(function(){ map.invalidateSize && map.invalidateSize(); }, 200);
          return;
        }

        const addr = node.getAttribute('data-address');
        if(!addr) return;
        try{
          const pos = await geocode(addr);
          if(pos){
            const map = createMap(node, pos.lat, pos.lon, zoomAttr);
            setTimeout(function(){ map.invalidateSize && map.invalidateSize(); }, 200);
          }
        }catch(err){
          console.error('maps_osm geocode error for', addr, err);
        }
      })();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMaps);
  } else {
    // document already parsed
    initMaps();
  }

})();
