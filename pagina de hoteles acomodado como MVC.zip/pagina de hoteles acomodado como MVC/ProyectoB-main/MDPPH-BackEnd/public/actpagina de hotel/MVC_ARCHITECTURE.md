# Arquitectura MVC - Hotel Booking System

## Estructura de Carpetas

```
proyecto/
├── src/
│   ├── models/
│   │   ├── MapModel.js          # Lógica de geocodificación y mapas
│   │   └── HotelModel.js        # Base de datos de hoteles/paquetes
│   ├── controllers/
│   │   ├── MapViewController.js  # Renderización de mapas
│   │   └── ModalController.js    # Gestión de modales
│   ├── views/
│   │   └── (componentes reutilizables futuros)
│   ├── tests/
│   │   └── integrity.html       # Suite de pruebas
│   └── app.js                   # Inicializador principal
├── vendor/
│   └── leaflet/                 # Leaflet local
├── hotel_*.html                 # Páginas modificadas para usar MVC
├── paquete_*.html
└── ...
```

## Componentes MVC

### Models

#### MapModel
- **Responsabilidad**: Lógica de geocodificación y cálculo de coordenadas
- **Métodos principales**:
  - `geocode(address)` — convierte dirección a lat/lng
  - `isLeafletAvailable()` — verifica disponibilidad de librería
  - `getPosition(lat, lng, address)` — obtiene coordinadas de cualquier fuente
- **Caché**: Guarda resultados de geocodificación para evitar llamadas repetidas

#### HotelModel
- **Responsabilidad**: Almacenamiento y validación de datos de hoteles/paquetes
- **Métodos principales**:
  - `getHotel(id)` — obtiene hotel por ID
  - `getPackage(id)` — obtiene paquete por ID
  - `getAllHotels()`, `getAllPackages()` — obtiene todos los registros
  - `validate()` — valida integridad de datos
- **Datos**: Base de datos local (JSON) de hoteles y paquetes

### Controllers

#### MapViewController
- **Responsabilidad**: Renderizar mapas de Leaflet en el DOM
- **Métodos principales**:
  - `createMap(container, lat, lon, zoom)` — crea una instancia de mapa
  - `initMaps()` — inicializa todos los mapas en la página
- **Automático**: Se ejecuta al cargar el DOM

#### ModalController
- **Responsabilidad**: Gestionar modales de reservación
- **Métodos principales**:
  - `openModal()` / `closeModal()` — abre/cierra modal de reservación
  - `openConfirmModal()` / `closeConfirmModal()` — abre/cierra confirmación
  - `getFormData()` — obtiene datos del formulario
  - `clearForm()` — limpia el formulario
- **Automático**: Configuración de event listeners al cargar

### App.js
- **Responsabilidad**: Inicialización y chequeo de integridad
- **Métodos principales**:
  - `init()` — inicializa la app
  - `checkIntegrity()` — valida que todos los módulos estén cargados
  - `getStatus()` — retorna estado actual

## Integración con HTML

Cada página (HTML) incluye los scripts en este orden:

```html
<!-- Leaflet CDN o local -->
<script src="vendor/leaflet/leaflet.js"></script>

<!-- Models -->
<script src="src/models/MapModel.js"></script>
<script src="src/models/HotelModel.js"></script>

<!-- Controllers -->
<script src="src/controllers/MapViewController.js"></script>
<script src="src/controllers/ModalController.js"></script>

<!-- App -->
<script src="src/app.js"></script>

<!-- Legacy scripts (opcional) -->
<script src="ventana_modal_*.js"></script>
<script src="cambiar_temas_en_ajustes.js"></script>
```

**Orden es importante**: Models → Controllers → App

## Pruebas de Integridad

Abre en navegador:
```
http://localhost:8000/src/tests/integrity.html
```

Las pruebas verifican:
- ✓ Todos los módulos están cargados
- ✓ Leaflet está disponible
- ✓ Datos de hoteles/paquetes son válidos
- ✓ Funciones clave están definidas
- ✓ App está inicializada

## Debugging

Habilitar logs detallados en consola:
```javascript
// En consola del navegador:
window.DEBUG_MVC = true;
```

Verificar estado:
```javascript
App.getStatus();
MapModel.isLeafletAvailable();
HotelModel.validate();
```

## Compatibilidad

- **Backward Compatible**: Los archivos antiguos (`maps_osm.js`, `maps_config.js`) siguen disponibles
- **Migración Gradual**: Puedes cambiar pages una por una
- **Sin Romper**: Las páginas antiguas seguirán funcionando

## Próximos Pasos

1. Mover CSS a carpeta `src/styles/`
2. Crear `FormValidationController` para validación de formularios
3. Crear `ThemeController` para gestión de temas
4. Crear componentes reutilizables en `src/views/`
5. Implementar base de datos en backend (Node.js)

## Notas

- Los modales aún dependen de `ventana_modal_*.js` legacy (se pueden refactorizar más adelante)
- El cambio de temas usa `cambiar_temas_en_ajustes.js` legacy
- Los mapas ahora son 100% MVC mediante `MapViewController`
