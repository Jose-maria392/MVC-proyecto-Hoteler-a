// Bloqueo: Si no hay token, no puedes estar aquí
//(function () {
    //const token = localStorage.getItem('token');
    //if (!token) {
        // Si intenta entrar sin token, lo mandamos al login de inmediato
        //window.location.replace('../view/login.html');
    //}
//})();

async function enviarReservacion() {
    const reservarAhoraBtn = document.getElementById('reservarAhoraBtn');
    const btnConfirmarPago = document.getElementById('btnConfirmarPago');

    if (!reservarAhoraBtn) return;

    if (btnConfirmarPago) {
        btnConfirmarPago.onclick = function () {
            window.location.replace('./');
        };
    }

    reservarAhoraBtn.onclick = async function () {
        const token = localStorage.getItem('token');
        if (!token) {
            alert("¡Alto! Debes iniciar sesión para reservar.");
            window.location.replace('../view/login.html');
            return; // Se detiene el proceso aquí
        }

        // 1. Identificamos el lugar automáticamente del hotel o paquete por el <h1>
        const hotelNombre = document.querySelector('h1').textContent;
        // 2. Capturamos los datos
        const nombre = document.getElementById('nombreHuesped').value.trim();
        const fecha = document.getElementById('fechaReservacion').value;
        const selectIntegrantes = document.getElementById('integrantes');
        const tipoIntegrantes = selectIntegrantes.value;
        const cantidadOtroInput = document.getElementById('cantidadOtro');

        // 3. Validaciones 
        let esValido = true;

        // Ejemplo de validación visual (se puede repetir para los demás campos)
        if (!nombre) {
            document.getElementById('error-nombre');
            if (err) { err.textContent = "El nombre es obligatorio"; err.classList.add('show'); }
            esValido = false;
        }

        if (!esValido) return;

        // 4. Lógica de integrantes
        let cantidadIntegrantes = 0;
        if (tipoIntegrantes === 'otro') {
            cantidadIntegrantes = parseInt(cantidadOtroInput.value) || 0;
        } else {
            const mappings = { '1-6': 6, '1-12': 12, '2': 2 };
            cantidadIntegrantes = mappings[tipoIntegrantes];
        }

        const reservationData = {
            nombreHuesped: nombre,
            fechaReservacion: fecha,
            tipoIntegrantes: tipoIntegrantes,
            cantidadIntegrantes: cantidadIntegrantes,
            hotel: hotelNombre
        };

        try {
            const token = localStorage.getItem('token');
            if (!token) {
                mostrarMensajeError("Debes iniciar sesión para reservar.");
                setTimeout(() => window.location.replace('../view/login.html'), 2000);
                return;
            }

            // URL para el servidor
            const response = await fetch('https://summital-rosamond-driverless.ngrok-free.dev/api/reservation/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` // Importante para el middleware de auth
                },
                body: JSON.stringify(reservationData)
            });

            if (response.ok) {
                // Aquí se abre el modal de "Éxito"
                cerrarModal('miModal');
                abrirModal('modalPagarExito');
            } else {
                const errorData = await response.json();
                mostrarMensajeError(errorData.message || "No se pudo realizar la reserva");
            }
        } catch (error) {
            mostrarMensajeError("Error de conexión con el servidor.");
        }
    };
}

// Función auxiliar para no repetir código de errores
function mostrarMensajeError(msg) {
    const alertaGlobal = document.getElementById('error-general-reservas'); // Si creas uno
    if (alertaGlobal) {
        alertaGlobal.textContent = msg;
        alertaGlobal.style.display = 'block';
    } else {
        // Si no hay contenedor
        console.warn("Error:", msg);
    }
}