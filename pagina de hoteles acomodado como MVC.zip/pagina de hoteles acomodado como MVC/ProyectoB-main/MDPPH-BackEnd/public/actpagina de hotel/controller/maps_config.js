/* Centraliza la API key de Google Maps y carga iframes con `data-maps-query` */
(function(window){
  // Cambia 'TU_API_KEY' por tu clave real aquí
  const MAPS_API_KEY = 'TU_API_KEY';

  function initMapIframes(){
    document.querySelectorAll('iframe[data-maps-query]').forEach(function(iframe){
      var q = iframe.getAttribute('data-maps-query');
      if(!q) return;
      var url = 'https://www.google.com/maps/embed/v1/place?key=' + encodeURIComponent(MAPS_API_KEY) + '&q=' + encodeURIComponent(q);
      iframe.setAttribute('src', url);
    });
  }

  document.addEventListener('DOMContentLoaded', initMapIframes);

  // Exponer para uso manual si se necesita
  window.MapsConfig = {
    init: initMapIframes
  };
})(window);
