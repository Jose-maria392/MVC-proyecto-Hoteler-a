// Variables para los elementos del DOM del formulario
const modal = document.getElementById('miModal');
const abrirBtn = document.getElementById('abrirModalBtn');
const cancelarBtn = document.getElementById('cancelarBtn');
const reservarAhoraBtn = document.getElementById('reservarAhoraBtn');
const selectIntegrantes = document.getElementById('integrantes');
const otroIntegrantesDiv = document.getElementById('otroIntegrantesDiv');
const cantidadOtroInput = document.getElementById('cantidadOtro');

// Elementos de error
const errorNombre = document.getElementById('error-nombre');
const errorIntegrantes = document.getElementById('error-integrantes');
const errorCantidad = document.getElementById('error-cantidad');
const errorFecha = document.getElementById('error-fecha');

// Campos del formulario
const campoNombre = document.getElementById('nombreHuesped');
const campoIntegrantes = document.getElementById('integrantes');
const campoFecha = document.getElementById('fechaReservacion');
const campoCantidad = document.getElementById('cantidadOtro');

// Funciones de validación visual
function mostrarError(campo, mensaje, errorElement) {
    campo.classList.add('input-error');
    campo.classList.remove('input-valid');
    errorElement.textContent = mensaje;
    errorElement.classList.add('show');
}

function ocultarError(campo, errorElement) {
    campo.classList.remove('input-error');
    campo.classList.remove('input-valid');
    errorElement.textContent = '';
    errorElement.classList.remove('show');
}

function limpiarErrores() {
    ocultarError(campoNombre, errorNombre);
    ocultarError(campoIntegrantes, errorIntegrantes);
    ocultarError(campoFecha, errorFecha);
    ocultarError(campoCantidad, errorCantidad);
}

// Validación en tiempo real (opcional - al escribir)
campoNombre.addEventListener('input', () => {
    if (campoNombre.value.trim()) {
        ocultarError(campoNombre, errorNombre);
    }
});

campoFecha.addEventListener('change', () => {
    if (campoFecha.value) {
        ocultarError(campoFecha, errorFecha);
    }
});

selectIntegrantes.addEventListener('change', () => {
    if (selectIntegrantes.value) {
        ocultarError(campoIntegrantes, errorIntegrantes);
    }
});

// Resto de tu código existente (modales, etc.) se mantiene igual...
// [Incluye aquí todas tus funciones showConfirmation, closeConfirmation, etc.]
// --- FUNCIONALIDAD PARA ABRIR Y CERRAR EL MODAL DEL FORMULARIO ---
abrirBtn.onclick = function() {
    modal.style.display = 'block';
}

cancelarBtn.onclick = function() {
    modal.style.display = 'none';
}

// Cerrar modal del formulario si hace clic fuera
window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}

// variable para la modal de confirmacion
const modalConfirmacion = document.getElementById('modalConfirmacion');

// --- LÓGICA PARA EL BOTÓN "RESERVAR AHORA" MEJORADA ---
reservarAhoraBtn.onclick = function() {
    limpiarErrores(); // Limpiar errores previos
    let esValido = true;

    // Validar nombre
    if (!campoNombre.value.trim()) {
        mostrarError(campoNombre, 'El nombre del huésped es obligatorio', errorNombre);
        esValido = false;
    }

    // Validar fecha
    if (!campoFecha.value) {
        mostrarError(campoFecha, 'Selecciona la fecha de reservación', errorFecha);
        esValido = false;
    }

    // Validar select integrantes
    if (!selectIntegrantes.value) {
        mostrarError(campoIntegrantes, 'Selecciona el tipo de reservación', errorIntegrantes);
        esValido = false;
    }

    // Validar campo "otro"
    if (selectIntegrantes.value === 'otro') {
        const cantidad = campoCantidad.value;
        if (!cantidad || isNaN(cantidad) || parseInt(cantidad) <= 0) {
            mostrarError(campoCantidad, 'Ingresa una cantidad válida (mínimo 1)', errorCantidad);
            esValido = false;
        }
    }

    // Si hay errores, NO continuar
    if (!esValido) {
        return;
    }

    // ✅ TODO VÁLIDO - Proceder con confirmación
    const nombre = campoNombre.value.trim();
    const fecha = campoFecha.value;
    //const fecha = new Date(campoFecha.value).toLocaleDateString('es-MX');
    const tipoIntegrantes = selectIntegrantes.value;
    //let integrantesTexto = '';
    let textoIntegrantes = '';
    //let cantidadParaPrecio = null;
    let cantidadPersonalizada = null;

    if (tipoIntegrantes === 'otro') {
        //const cantidad = campoCantidad.value;
        //integrantes = `Otro (${campoCantidad.value} integrantes)`;
        cantidadPersonalizada = campoCantidad.value;
        textoIntegrantes = `Personalizado (${cantidadPersonalizada} integrantes)`;
    } else if (tipoIntegrantes === '1-6') {
        textoIntegrantes = 'Familiar (1 a 6)';
    } else if (tipoIntegrantes === '1-12') {
        textoIntegrantes = 'Grupal (1 a 12)';
    } else if (tipoIntegrantes === '2') {
        textoIntegrantes = 'Pareja (2)';
    }

    // cerrar modal formulario y mostrar confirmacion con precio
    modal.style.display = 'none';
    //showConfirmation(nombre, integrantes, fecha);
    mostrarConfirmacion(nombre, fecha, textoIntegrantes, cantidadPersonalizada);
    limpiarFormulario();
};

// === PRECIOS POR TIPO DE RESERVACION ===
const preciosPorTipo = {
    // Precio base por persona en MXN
    '1-6': { precio: 1500, nombre: 'Familiar', avg: 4 },  // 1-6 integrantes
    '1-12': { precio: 1200, nombre: 'Grupal', avg: 8 }, // 1-12 integrantes  
    '2': { precio: 2000, nombre: 'Pareja', avg: 2 }, // 2 integrantes (precio especial por persona)
    'otro': { precio: 1300, nombre: 'Personalizado', avg: 1 } // precio base para "otro"
};

// Función para calcular precio total
function calcularPrecio(tipoReservacion, cantidadPersonalizada = null) {
    const config = preciosPorTipo[tipoReservacion];
    if (!config) return { total: 0, detalles: ''};
    //let precioPorPersona;
    //let totalIntegrantes = 1; // Por defecto 1
    let numIntegrantes = config.avg;

    if (tipoReservacion === 'otro' && cantidadPersonalizada){
        numIntegrantes = parseInt(cantidadPersonalizada);
    }

    const total = config.precio * numIntegrantes;
    return {
        total: total,
        numIntegrantes: numIntegrantes,
        precioUnitario: config.precio,
        detalles: `${numIntegrantes} x $${config.precio.toLocaleString()} c/u`
    };

}

// funcion para mostrar modal de confirmacion
function mostrarConfirmacion(nombre, fecha, textoIntegrantes, cantidadPersonalizada = null) {
    document.getElementById('confirmNombre').textContent = nombre;
    document.getElementById('confirmFecha').textContent = fecha;
    document.getElementById('confirmIntegrantes').textContent = textoIntegrantes;
    modalConfirmacion.style.display = 'block';

    // obtener tipo de reservacion del select (necesitas pasarlo tambien)
    const tipoSeleccionado = document.getElementById('integrantes').value;

    //calcular precio
    const precioInfo = calcularPrecio(tipoSeleccionado, cantidadPersonalizada);
    // Calcular y Mostrar Precio
    //let precioInfo;
    //let cantidad = null;

    //if(tipoIntegrantes.includes('Otro')){
        //// Extraer cantidad del texto "Otro (5 integrantes)"
        //const match = tipoIntegrantes.match(/\((\d+)/);
        //cantidad = match ? parseInt(match[1]) : 1;
    //}

    //precioInfo = calcularPrecioTotal(tipoIntegrantes, cantidad);

    // Formulario precio con formato moneda MXN
    //formatear precio
    const precioFormateado = new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(precioInfo.total);

    //mostrar precio
    const precioElement = document.getElementById('confirmPrecio');
    if (precioElement){
        precioElement.textContent = `${precioFormateado} (${precioInfo.detalles})`;
        precioElement.style.color = '#28a745';
        precioElement.style.fontWeight = 'bold';
        precioElement.style.fontSize = '18px';
    } else {
        console.error('Elemento #confirmPrecio no encontrado');
    }
    // Mostrar precio en el modal
    //document.getElementById('confirmPrecio').textContent = `${precioFormateado} (${precioInfo.Integrantes} x $${precioInfo.porPersona.toLocaleString()} c/u)`;
    
    // Mostrar modal
    //modalConfirmacion.style.display = 'block';
}

// Resto de tus funciones (limpiarFormulario, eventos modales, etc.) se mantienen iguales
// --- LÓGICA PARA EL CAMPO "INTEGRANTES" ---
selectIntegrantes.onchange = function() {
    if (selectIntegrantes.value === 'otro') {
        otroIntegrantesDiv.classList.remove('input-hidden');
        cantidadOtroInput.setAttribute('required', 'required');
    } else {
        otroIntegrantesDiv.classList.add('input-hidden');
        cantidadOtroInput.removeAttribute('required');
        cantidadOtroInput.value = '';
    }
}

// Función para limpiar el formulario
function limpiarFormulario() {
    document.getElementById('nombreHuesped').value = '';
    document.getElementById('fechaReservacion').value = '';
    selectIntegrantes.value = '';
    otroIntegrantesDiv.classList.add('input-hidden');
    cantidadOtroInput.value = '';
}

// Función para abrir/cerrar modales
    function abrirModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
        document.body.style.overflow = 'hidden'; // Evita scroll del fondo
    }
    
    function cerrarModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
        document.body.style.overflow = 'auto'; // Restaura scroll
    }
    
    // Cerrar modales haciendo clic fuera de ellos
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            cerrarModal(event.target.id);
        }
    }
    
    // Event Listeners para los botones
    
    // Botón Pagar Reservación
    document.getElementById('btnPagar').addEventListener('click', function() {
        cerrarModal('modalConfirmacion');
        abrirModal('modalPagarExito');
    });
    
    // Botón Confirmar Pago
    document.getElementById('btnConfirmarPago').addEventListener('click', function() {
        cerrarModal('modalPagarExito');
        //alert('¡Reservación pagada exitosamente! 🎉'); // Aquí puedes redirigir o hacer otra acción
    });
    
    // Botón Cancelar Reservación
    document.getElementById('btnCancelar').addEventListener('click', function() {
        cerrarModal('modalConfirmacion');
        abrirModal('modalCancelarConfirmar');
    });
    
    // Botón "No" en modal de cancelar
    document.getElementById('btnCancelarNo').addEventListener('click', function() {
        cerrarModal('modalCancelarConfirmar');
        abrirModal('modalConfirmacion'); // Regresa al modal original
    });
    
    // Botón "Sí" en modal de cancelar
    document.getElementById('btnCancelarSi').addEventListener('click', function() {
        cerrarModal('modalCancelarConfirmar');
        abrirModal('modalCancelarExito');
    });
    
    // Botón Confirmar Cancelación Final
    document.getElementById('btnConfirmarCancelacion').addEventListener('click', function() {
        cerrarModal('modalCancelarExito');
        //alert('Reservación cancelada correctamente. 👋'); // Aquí puedes limpiar datos o redirigir
    });
    
    // EJEMPLO: Abrir modal de confirmación (llamar esta función desde tu formulario)
    function abrirModalConfirmacion(datos) {
        document.getElementById('confirmNombre').textContent = datos.nombre || 'N/A';
        document.getElementById('confirmFecha').textContent = datos.fecha || 'N/A';
        document.getElementById('confirmIntegrantes').textContent = datos.integrantes || 'N/A';
        document.getElementById('confirmPrecio').textContent = datos.precio || '$0.00 MXN';
        abrirModal('modalConfirmacion');
    }