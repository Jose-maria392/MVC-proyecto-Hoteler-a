document.addEventListener('DOMContentLoaded', () => {
    //const settingsButton = document.getElementById('settingsButton');
    const body = document.body;
    const THEME_KEY = 'userTheme'; // Clave para localStorage

    // Imágenes de fondo (ajusta rutas según tus archivos)
    // Para cambiar las imágenes, edita este array con los nombres de tus archivos en la carpeta correspondiente.
    const backgrounds = [
        "../assets/img_datos del hotel/imagenhotel_dos.jpg",
        "../assets/img_datos del hotel/imagenhotel_tres.jpg",
        "../assets/img_datos del hotel/imagenhotel_cuatro.jpg",
        "../assets/img_datos del hotel/imagenpaquete_uno.jpg",
        "../assets/img_datos del hotel/imagenpaquete_dos.jpg",
        "../assets/img_datos del hotel/imgenpaquete_tres.jpg"
    ];
    let bgIndex = 0;
    const BG_INTERVAL = 8000; // ms entre cambios
    const FADE_DURATION = 1200; // ms, debe coincidir con CSS transition

    // Slider con dos capas para crossfade
    const slide0 = document.getElementById('bg-slide-0');
    const slide1 = document.getElementById('bg-slide-1');
    let currentSlide = 0; // 0 o 1

    function setSlideBackground(element, imgUrl, isDark) {
        // Overlay gradient según tema
        const overlay = isDark ? 'linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),' : 'linear-gradient(rgba(255,255,255,0.12), rgba(255,255,255,0.12)),';
        element.style.backgroundImage = `${overlay} url('${imgUrl}')`;
    }

    function showNextSlide() {
        if (!slide0 || !slide1) return;

        const img = backgrounds[bgIndex];
        const isDark = body.classList.contains('dark-mode');

        const nextEl = currentSlide === 0 ? slide1 : slide0;
        const currEl = currentSlide === 0 ? slide0 : slide1;

        // Preparar siguiente imagen debajo y then fade in
        setSlideBackground(nextEl, img, isDark);
        nextEl.classList.add('visible');

        // Quitar visible de la actual tras la transición
        setTimeout(() => {
            currEl.classList.remove('visible');
        }, FADE_DURATION);

        currentSlide = currentSlide === 0 ? 1 : 0;
        bgIndex = (bgIndex + 1) % backgrounds.length;
    }

    // Inicia y maneja el slider
    let bgTimer = null;
    function startBackgroundSlider() {
        // Guardar estado y limpiar timer
        if (bgTimer) clearInterval(bgTimer);

        // Si no hay slides en DOM por alguna razón, abortar
        if (!slide0 || !slide1) return;

        // Establecer la primera imagen inmediatamente
        const firstImg = backgrounds[bgIndex];
        const isDark = body.classList.contains('dark-mode');
        setSlideBackground(slide0, firstImg, isDark);
        slide0.classList.add('visible');
        currentSlide = 0;
        bgIndex = (bgIndex + 1) % backgrounds.length;

        bgTimer = setInterval(showNextSlide, BG_INTERVAL);
    }

    // Aplica el tema: 'dark' o 'light'
    function applyTheme(theme) {
        if (theme === 'dark') {
            body.classList.add('dark-mode');
            //settingsButton.setAttribute('aria-pressed', 'true');
            //localStorage.setItem(THEME_KEY, 'dark');
        } else {
            body.classList.remove('dark-mode');
           // settingsButton.setAttribute('aria-pressed', 'false');
            //localStorage.setItem(THEME_KEY, 'light');
        }
        // Reiniciar el slider para aplicar overlay apropiado a la nueva imagen
        startBackgroundSlider();
    }

    // Alterna tema al hacer clic en el botón
    //settingsButton.addEventListener('click', () => {
       // const isDark = body.classList.contains('dark-mode');
       // applyTheme(isDark ? 'light' : 'dark');
    //});

    // Carga la preferencia guardada (por defecto: claro)
    const savedTheme = localStorage.getItem(THEME_KEY) || 'light';
    applyTheme(savedTheme);
    // Asegura que el slider esté activo al cargar
    startBackgroundSlider();

    // --- Soporte para activar hover en dispositivos táctiles ---
    // Añade/remueve la clase `touch-hover` en .card y .card-title para simular :hover
    function enableTouchHover() {
        const supportsTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
        if (!supportsTouch) return; // sólo en dispositivos táctiles

        //const touchTargets = Array.from(document.querySelectorAll('.card, .card-title'));
        const touchTargets = document.querySelectorAll('.card, .card-title');

        touchTargets.forEach((el) => {
            let touchTimeout = null;
            //aqui quite el el parentesis la "e"
            el.addEventListener('touchstart', () => {
                // Añade clase inmediatamente
                el.classList.add('touch-hover');
                // Si el elemento es un enlace, no impedir la navegación; solo mostrar efecto
                if (touchTimeout) clearTimeout(touchTimeout);
            }, {passive: true});

            el.addEventListener('touchend', () => { // aqui tambien quite la "e" del parentesis
                // Mantén el efecto un breve momento para que sea visible
                if (touchTimeout) clearTimeout(touchTimeout);
                touchTimeout = setTimeout(() => el.classList.remove('touch-hover'), 500);
            }, {passive: true});

            //el.addEventListener('touchcancel', (e) => {
                //if (touchTimeout) clearTimeout(touchTimeout);
                //el.classList.remove('touch-hover');
           // }, {passive: true});

            // Evita que un gesto de arrastre deje la clase activa
            //el.addEventListener('touchmove', (e) => {
               // if (touchTimeout) clearTimeout(touchTimeout);
               // el.classList.remove('touch-hover');
           // }, {passive: true});
        });
    }

    enableTouchHover();
});