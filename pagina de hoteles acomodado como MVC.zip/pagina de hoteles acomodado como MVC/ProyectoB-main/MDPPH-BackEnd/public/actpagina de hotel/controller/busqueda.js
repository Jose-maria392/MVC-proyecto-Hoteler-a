
/**
 * busqueda.js
 * Sistema de búsqueda de hoteles y paquetes con autocompletado
 * Este archivo se incluye en todas las páginas con barra de búsqueda
 */

// Función para crear los modales de búsqueda si no existen
function crearModalesBusqueda() {
    // Verificar si ya existen los modales
    if (document.getElementById('modalResultadosBusqueda')) {
        return;
    }

    // Crear modal de resultados
    const modalResultados = document.createElement('div');
    modalResultados.id = 'modalResultadosBusqueda';
    modalResultados.className = 'modal-resultados-busqueda';
    modalResultados.innerHTML = `
        <div class="modal-content-resultados">
            <button class="cerrar-resultados" onclick="cerrarModalBusqueda('modalResultadosBusqueda')">&times;</button>
            <h2 class="titulo-resultados" id="tituloResultadosBusqueda">Resultados de búsqueda</h2>
            <div id="contenidoResultadosBusqueda"></div>
        </div>
    `;

    // Crear modal de error
    const modalError = document.createElement('div');
    modalError.id = 'modalErrorBusqueda';
    modalError.className = 'modal-error-busqueda';
    modalError.innerHTML = `
        <div class="modal-content-error">
            <div class="icono-error">🔍</div>
    <h2 class="titulo-error">No encontrado</h2>
            <p class="mensaje-error" id="mensajeErrorBusqueda"></p>
            <button class="boton-entendido" onclick="cerrarErrorYLimpiar()">Entendido</button>
        </div>
    `;

    // Agregar al body
    document.body.appendChild(modalResultados);
    document.body.appendChild(modalError);
}

// Datos dinámicos de HotelModel (si disponible) o fallback
function getSearchData() {
    if (typeof HotelModel !== 'undefined') {
        const hotels = HotelModel.getAllHotels().map(h => ({
            id: h.id,
            name: h.name,
            type: 'hotel',
            href: h.id + '.html',
            image: `../assets/img_datos del hotel/imagenhotel_${h.id.split('_')[1] || 'dos'}.jpg`,
            rating: h.rating,
            address: h.address
        }));
        const packages = HotelModel.getAllPackages().map(p => ({
            id: p.id,
            name: p.name,
            type: 'paquete',
            href: p.id + '.html',
            image: `../assets/img_datos del hotel/Imagenpaquete_${p.id.split('_')[1] || 'uno'}.jpg`,
            rating: p.rating,
            address: p.address
        }));
        return { hotels, packages };
    }
    // Fallback datos hardcodeados
    return {
        hotels: [
            { id: 'hotel_uno', name: 'La Montaña Mágica', type: 'hotel', href: '../view/hotel_uno.html', image: '../assets/img_datos del hotel/imagenhotel_dos.jpg', rating: 4, address: '' },
            { id: 'hotel_dos', name: 'Hotel La Palmera Dorada', type: 'hotel', href: '../view/hotel_dos.html', image: '../assets/img_datos del hotel/imagenhotel_tres.jpg', rating: 4, address: '' },
            { id: 'hotel_tres', name: 'El Paraíso Perdido', type: 'hotel', href: '../view/hotel_tres.html', image: '../assets/img_datos del hotel/imagenhotel_cuatro.jpg', rating: 4, address: '' }
        ],
        packages: [
            { id: 'hotel_uno', name: 'La Montaña Mágica', type: 'paquete', href: '../view/paquete_uno.html', image: '../assets/img_datos del hotel/imagenpaquete_uno.jpg', rating: 4, address: '' },
            { id: 'paquete_dos', name: 'Hotel La Palmera Dorada', type: 'paquete', href: '../view/paquete_dos.html', image: '../assets/img_datos del hotel/imagenpaquete_dos.jpg', rating: 4, address: '' },
            { id: 'paquete_tres', name: 'El Paraíso Perdido', type: 'paquete', href: '../view/paquete_tres.html', image: '../assets/img_datos del hotel/imgenpaquete_tres.jpg', rating: 4, address: '' }
        ]
    };
}


// Función para obtener todas las estrellas según rating
function getEstrellas(rating) {
    return '⭐'.repeat(rating);
}

// Función fuzzy search mejorada
function fuzzyScore(query, str) {
    const q = query.toLowerCase().replace(/[^a-z0-9]/g, '');
    const s = str.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (s.includes(q)) return 1.0;
    let score = 0;
    for (let i = 0; i < q.length; i++) {
        if (s.includes(q[i])) score += 0.2;
    }
    return score / q.length;
}

// Función para realizar la búsqueda (ahora fuzzy + ordenada)
function buscar(query) {
    const busqueda = query.toLowerCase().trim();
    
    if (!busqueda) {
        return [];
    }
    
    const data = getSearchData();
    const todos = [...data.hotels, ...data.packages];
    
    const resultados = todos
        .map(item => ({
            ...item,
            score: fuzzyScore(busqueda, item.name)
        }))
        .filter(item => item.score > 0.2)
        .sort((a, b) => b.score - a.score);
    
    return resultados;
}


// Función para obtener sugerencias de autocompletado (ahora fuzzy)
function obtenerSugerencias(query) {
    const busqueda = query.toLowerCase().trim();
    
    if (!busqueda || busqueda.length < 1) {
        return [];
    }
    
    return buscar(busqueda).slice(0, 5);
}


// Función para generar HTML de las tarjetas de resultados
function generarHTMLResultados(resultados) {
    let html = '<div class="resultados-grid">';
    
    resultados.forEach(item => {
        const tipoLabel = item.type === 'hotel' ? '🏨 Hotel' : '🎁 Paquete';
        
        html += `
            <div class="resultado-card">
                <img src="${item.image}" alt="${item.name}" class="resultado-image">
                <div class="resultado-content">
                    <span class="resultado-tipo">${tipoLabel}</span>
                    <h3 class="resultado-titulo">${item.name}</h3>
                    <p class="resultado-rating">${getEstrellas(item.rating)}</p>
                    <a href="${item.href}" class="resultado-boton">Ver más</a>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    return html;
}

// Función para generar HTML de las sugerencias de autocompletado
function generarHTMLSugerencias(sugerencias) {
    if (sugerencias.length === 0) {
        return '<div class="sugerencia-vacia">No hay sugerencias</div>';
    }
    
    let html = '<ul class="sugerencias-list">';
    
    sugerencias.forEach(item => {
        const tipoIcon = item.type === 'hotel' ? '🏨' : '🎁';
        html += `
            <li class="sugerencia-item" data-href="${item.href}">
                <span class="sugerencia-icon">${tipoIcon}</span>
                <span class="sugerencia-nombre">${item.name}</span>
                <span class="sugerencia-tipo">${item.type === 'hotel' ? 'Hotel' : 'Paquete'}</span>
            </li>
        `;
    });
    
    html += '</ul>';
    return html;
}

// Función para mostrar el autocompletado
function mostrarAutocompletado(sugerencias, input) {
    let contenedor = document.getElementById('contenedorAutocompletado');
    
    // Crear el contenedor si no existe
    if (!contenedor) {
        contenedor = document.createElement('div');
        contenedor.id = 'contenedorAutocompletado';
        contenedor.className = 'autocompletado-contenedor';
        input.parentNode.appendChild(contenedor);
    }
    
    if (sugerencias.length === 0) {
        contenedor.style.display = 'none';
        return;
    }
    
    contenedor.innerHTML = generarHTMLSugerencias(sugerencias);
    contenedor.style.display = 'block';
    
    // Agregar eventos a las sugerencias
    const items = contenedor.querySelectorAll('.sugerencia-item');
    items.forEach(item => {
        item.addEventListener('click', function() {
            const href = this.getAttribute('data-href');
            if (href) {
                window.location.href = href;
            }
        });
    });
}

// Función para generar HTML de resultados en vivo
function generarHTMLResultadosEnVivo(resultados, query) {
    if (!query) {
        return '';
    }

    if (resultados.length === 0) {
        return `
            <div class="resultado-vivo-vacio">
                No se encontraron coincidencias para "<strong>${query}</strong>"
            </div>
        `;
    }

    let html = `
        <div class="resultados-vivos-header">
            <span>Resultados encontrados: ${resultados.length}</span>
        </div>
        <div class="resultados-vivos-lista">
    `;

    resultados.slice(0, 6).forEach(item => {
        const tipoIcon = item.type === 'hotel' ? '🏨' : '🎁';
        const tipoTexto = item.type === 'hotel' ? 'Hotel' : 'Paquete';

        html += `
            <a href="${item.href}" class="resultado-vivo-item">
                <img src="${item.image}" alt="${item.name}" class="resultado-vivo-imagen">
                <div class="resultado-vivo-info">
                    <span class="resultado-vivo-tipo">${tipoIcon} ${tipoTexto}</span>
                    <strong class="resultado-vivo-nombre">${item.name}</strong>
                    <span class="resultado-vivo-rating">${getEstrellas(item.rating)}</span>
                </div>
            </a>
        `;
    });

    html += '</div>';
    return html;
}

// Función para mostrar resultados dinámicos mientras el usuario escribe
function mostrarResultadosEnVivo(resultados, input, query) {
    let contenedor = document.getElementById('contenedorResultadosVivos');

    if (!contenedor) {
        contenedor = document.createElement('div');
        contenedor.id = 'contenedorResultadosVivos';
        contenedor.className = 'resultados-vivos-contenedor';
        input.parentNode.appendChild(contenedor);
    }

    if (!query || query.length < 1) {
        contenedor.style.display = 'none';
        return;
    }

    contenedor.innerHTML = generarHTMLResultadosEnVivo(resultados, query);
    contenedor.style.display = 'block';
}

function ocultarResultadosEnVivo() {
    const contenedor = document.getElementById('contenedorResultadosVivos');
    if (contenedor) {
        contenedor.style.display = 'none';
    }
}

// Función para ocultar el autocompletado
function ocultarAutocompletado() {
    const contenedor = document.getElementById('contenedorAutocompletado');
    if (contenedor) {
        contenedor.style.display = 'none';
    }
}

// Función para mostrar el modal de resultados
function mostrarResultados(resultados, query, filters = {}) {
    // Asegurar que los modales existan
    crearModalesBusqueda();
    
    const modal = document.getElementById('modalResultadosBusqueda');
    const contenido = document.getElementById('contenidoResultadosBusqueda');
    const titulo = document.getElementById('tituloResultadosBusqueda');
    
    // Filtros profesionales
    const filtroHTML = `
        <div class="filtros-container">
            <select id="filtroTipo" onchange="aplicarFiltros('${query}')">
                <option value="todos">Todos (${resultados.length})</option>
                <option value="hotel">🏨 Hoteles</option>
                <option value="paquete">🎁 Paquetes</option>
            </select>
            <select id="filtroRating" onchange="aplicarFiltros('${query}')">
                <option value="0">⭐ Rating mínimo</option>
                <option value="3">⭐⭐⭐+</option>
                <option value="4">⭐⭐⭐⭐+</option>
                <option value="5">⭐⭐⭐⭐⭐</option>
            </select>
            <button onclick="buscar('${query}')" class="btn-buscar-nuevo">🔍 Buscar</button>
        </div>
    `;
    
    if (resultados.length === 0) {
        mostrarErrorBusqueda(query);
        return;
    }
    
    titulo.textContent = `Resultados para "${query}" (${resultados.length})`;
    contenido.innerHTML = filtroHTML + generarHTMLResultados(resultados);
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Filtros profesionales
function aplicarFiltros(query) {
    const tipo = document.getElementById('filtroTipo').value;
    const ratingMin = parseInt(document.getElementById('filtroRating').value) || 0;
    
    const todos = buscar(query);
    const filtrados = todos.filter(item => 
        (tipo === 'todos' || item.type === tipo) &&
        item.rating >= ratingMin
    );
    
    document.getElementById('tituloResultadosBusqueda').textContent = `Resultados filtrados (${filtrados.length})`;
    document.getElementById('contenidoResultadosBusqueda').innerHTML = 
        document.querySelector('.filtros-container').outerHTML + generarHTMLResultados(filtrados);
}


// Función para mostrar el modal de error
function mostrarErrorBusqueda(query) {
    // Asegurar que los modales existan
    crearModalesBusqueda();
    
    const modal = document.getElementById('modalErrorBusqueda');
    const mensaje = document.getElementById('mensajeErrorBusqueda');
    
    mensaje.innerHTML = `Lo que buscas no existe o no está por el momento.`;
    
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Función para cerrar cualquier modal de búsqueda
function cerrarModalBusqueda(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Función para cerrar modal de error y limpiar búsqueda
function cerrarErrorYLimpiar() {
    cerrarModalBusqueda('modalErrorBusqueda');
    const inputBusqueda = document.querySelector('.search-input');
    if (inputBusqueda) {
        inputBusqueda.value = '';
    }
    ocultarAutocompletado();
    ocultarResultadosEnVivo();
}

// Inicializar el sistema de búsqueda
function iniciarBusqueda() {
    // Crear los modales si no existen
    crearModalesBusqueda();
    
    // Buscar el formulario de búsqueda
    const formBusqueda = document.querySelector('.navbar-center form');
    const inputBusqueda = document.querySelector('.search-input');
    
    if (formBusqueda && inputBusqueda) {
        // Posicionar el formulario relativamente para el autocompletado
        formBusqueda.style.position = 'relative';
        
        // Prevenir el envío tradicional del formulario
        formBusqueda.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const query = inputBusqueda.value.trim();
            
            if (query) {
                const resultados = buscar(query);
                mostrarResultados(resultados, query);
            }
        });
        
        // También buscar al hacer clic en el botón de búsqueda
        const btnBusqueda = document.querySelector('.search-button');
        if (btnBusqueda) {
            btnBusqueda.addEventListener('click', function(e) {
                e.preventDefault();
                
                const query = inputBusqueda.value.trim();
                
                if (query) {
                    const resultados = buscar(query);
                    mostrarResultados(resultados, query);
                }
            });
        }
        
        // Permitir buscar con Enter en el input
        inputBusqueda.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                
                const query = inputBusqueda.value.trim();
                
                if (query) {
                    const resultados = buscar(query);
                    mostrarResultados(resultados, query);
                }
            }
        });
        
        // Autocompletado y búsqueda dinámica mientras escribe
    inputBusqueda.addEventListener('input', function() {
            const query = this.value.trim();
            
            if (query.length >= 1) {
                const sugerencias = obtenerSugerencias(query);
                mostrarAutocompletado(sugerencias, this);
            } else {
                ocultarAutocompletado();
            }
        });
        
        // Ocultar paneles al perder el foco (con delay para permitir clic)
        inputBusqueda.addEventListener('blur', function() {
            setTimeout(ocultarAutocompletado, 200);
        });
        
        // Mostrar autocompletado y resultados al hacer focus si hay texto
        inputBusqueda.addEventListener('focus', function() {
            const query = this.value.trim();
            if (query.length >= 1) {
                const sugerencias = obtenerSugerencias(query);
                mostrarAutocompletado(sugerencias, this);
            }
        });
    }
    
    // Cerrar modales al hacer clic fuera
    window.addEventListener('click', function(e) {
        const modalResultados = document.getElementById('modalResultadosBusqueda');
        if (e.target === modalResultados) {
            cerrarModalBusqueda('modalResultadosBusqueda');
        }
        
        const modalError = document.getElementById('modalErrorBusqueda');
        if (e.target === modalError) {
            cerrarErrorYLimpiar();
        }
    });
    
    // Cerrar con Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            cerrarModalBusqueda('modalResultadosBusqueda');
            cerrarModalBusqueda('modalErrorBusqueda');
            ocultarAutocompletado();
            ocultarResultadosEnVivo();
        }
    });
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    iniciarBusqueda();
});
