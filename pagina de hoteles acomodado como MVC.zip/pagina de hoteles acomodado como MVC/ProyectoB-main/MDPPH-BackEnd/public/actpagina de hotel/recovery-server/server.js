require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const CODE_EXPIRY_SECONDS = parseInt(process.env.CODE_EXPIRY_SECONDS || '600', 10);

// Rate limiting configuration (configurable via env)
const RATE_LIMIT_WINDOW_MINUTES = parseInt(process.env.RATE_LIMIT_WINDOW_MINUTES || '60', 10);
const RATE_LIMIT_IP_MAX = parseInt(process.env.RATE_LIMIT_IP_MAX || '10', 10);
const RATE_LIMIT_EMAIL_MAX = parseInt(process.env.RATE_LIMIT_EMAIL_MAX || '3', 10);
const RATE_LIMIT = {
  ip: { windowMs: RATE_LIMIT_WINDOW_MINUTES * 60 * 1000, max: RATE_LIMIT_IP_MAX },
  email: { windowMs: RATE_LIMIT_WINDOW_MINUTES * 60 * 1000, max: RATE_LIMIT_EMAIL_MAX }
};

// Rate limit stores: map -> key => [timestamps]
const rateIpStore = new Map();
const rateEmailStore = new Map();

function pruneOld(timestamps, windowMs) {
  const cutoff = Date.now() - windowMs;
  while (timestamps.length && timestamps[0] < cutoff) timestamps.shift();
}

function isRateLimited(store, key, windowMs, max) {
  if (!key) return false;
  const arr = store.get(key) || [];
  pruneOld(arr, windowMs);
  if (arr.length >= max) return true;
  // add current timestamp and store back
  arr.push(Date.now());
  store.set(key, arr);
  return false;
}

// In-memory store: { emailLower: { code: '1234', expiresAt: Date } }
const codes = new Map();

// Validate env for nodemailer
if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.FROM_EMAIL) {
  console.warn('Warning: missing SMTP env variables. Copy .env.example to .env and set SMTP_HOST, SMTP_USER, SMTP_PASS, FROM_EMAIL');
}

// Configure transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587,
  secure: (process.env.SMTP_SECURE === 'true'),
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

function generateCode() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

function storeCode(email, code) {
  const expiresAt = Date.now() + CODE_EXPIRY_SECONDS * 1000;
  codes.set(email.toLowerCase(), { code, expiresAt });
}

function verifyCode(email, code) {
  const entry = codes.get(email.toLowerCase());
  if (!entry) return false;
  if (Date.now() > entry.expiresAt) {
    codes.delete(email.toLowerCase());
    return false;
  }
  const ok = String(entry.code) === String(code).trim();
  if (ok) codes.delete(email.toLowerCase());
  return ok;
}

// Optional cleanup interval
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of codes.entries()) {
    if (val.expiresAt < now) codes.delete(key);
  }
}, 60 * 1000);

app.post('/api/send-recovery', async (req, res) => {
  const { email } = req.body || {};
  if (!email || typeof email !== 'string') return res.status(400).json({ ok: false, error: 'Email requerido' });

  // Rate limit checks: by IP and by email
  const ip = (req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress || '').toString();
  if (isRateLimited(rateIpStore, ip, RATE_LIMIT.ip.windowMs, RATE_LIMIT.ip.max)) {
    const retryAfter = Math.ceil(RATE_LIMIT.ip.windowMs / 1000);
    res.set('Retry-After', String(retryAfter));
    return res.status(429).json({ ok: false, error: 'Demasiadas solicitudes desde esta IP. Intenta más tarde.' });
  }
  if (isRateLimited(rateEmailStore, email.toLowerCase(), RATE_LIMIT.email.windowMs, RATE_LIMIT.email.max)) {
    const retryAfter = Math.ceil(RATE_LIMIT.email.windowMs / 1000);
    res.set('Retry-After', String(retryAfter));
    return res.status(429).json({ ok: false, error: 'Demasiadas solicitudes para este correo. Intenta más tarde.' });
  }

  const code = generateCode();
  storeCode(email, code);

  // Compose message
  const mailOptions = {
    from: process.env.FROM_EMAIL,
    to: email,
    subject: 'Código de recuperación - Tu sitio',
    text: `Tu código de recuperación es: ${code}`,
    html: `<p>Tu código de recuperación es: <strong>${code}</strong></p><p>Este código expira en ${CODE_EXPIRY_SECONDS/60} minutos.</p>`
  };

  try {
    if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
      await transporter.sendMail(mailOptions);
      return res.json({ ok: true, sent: true });
    } else {
      // No SMTP configured: return simulated response but still store code
      console.log('[recovery-server] No SMTP configured; simulated send. Code for', email, ':', code);
      // Include the code in the response only in simulated mode (local/dev)
      return res.json({ ok: true, simulated: true, code, expiresInSeconds: CODE_EXPIRY_SECONDS });
    }
  } catch (err) {
    console.error('Error sending mail:', err);
    return res.status(500).json({ ok: false, error: 'Error al enviar correo' });
  }
});

app.post('/api/verify-code', (req, res) => {
  const { email, code } = req.body || {};
  if (!email || !code) return res.status(400).json({ ok: false, error: 'Email y código requeridos' });

  const ok = verifyCode(email, code);
  if (ok) return res.json({ ok: true });
  return res.status(400).json({ ok: false, error: 'Código inválido o expirado' });
});

app.listen(PORT, () => {
  console.log(`Recovery server listening on http://localhost:${PORT}`);
});
