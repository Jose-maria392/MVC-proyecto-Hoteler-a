Recovery server for sending 4-digit codes

Quickstart

1) Copy `.env.example` to `.env` and fill your SMTP credentials (or leave blank to run in simulated mode):

   - `SMTP_HOST` - your SMTP host
   - `SMTP_PORT` - 587 or 465
   - `SMTP_SECURE` - true for 465, false for 587
   - `SMTP_USER` - SMTP username
   - `SMTP_PASS` - SMTP password
   - `FROM_EMAIL` - e.g. "Mi Sitio <no-reply@example.com>"

2) Install dependencies (PowerShell):

```powershell
cd "c:\Users\yeige\OneDrive\Escritorio\actpagina de hotel\recovery-server"
npm install
```

3) Run the server (PowerShell):

```powershell
# For production
npm start
# For development (restarts automatically)
npm run dev
```

4) Update your front-end to call the endpoints:

- POST `http://localhost:3000/api/send-recovery` with JSON `{ "email": "user@example.com" }`.
- POST `http://localhost:3000/api/verify-code` with JSON `{ "email": "user@example.com", "code": "1234" }`.

If SMTP is not configured, the server will operate in simulated mode and still store the code in memory (useful for testing). The code expires after `CODE_EXPIRY_SECONDS` (default 600s).

Rate limiting
- You can configure rate limiting using environment variables in `.env`:
   - `RATE_LIMIT_WINDOW_MINUTES` (default 60)
   - `RATE_LIMIT_IP_MAX` (default 10)
   - `RATE_LIMIT_EMAIL_MAX` (default 3)

Example: to allow only 2 sends per email per 30 minutes (recommended for low-volume sites), set in `.env`:
```
RATE_LIMIT_WINDOW_MINUTES=30
RATE_LIMIT_EMAIL_MAX=2
```

Security note
- This is a minimal demo server intended for local development and testing. For production use:
  - Use a persistent store (DB) for codes, rate-limiting, and monitoring.
  - Require authentication for endpoints that change user state.
  - Use TLS and secure credentials storage.
