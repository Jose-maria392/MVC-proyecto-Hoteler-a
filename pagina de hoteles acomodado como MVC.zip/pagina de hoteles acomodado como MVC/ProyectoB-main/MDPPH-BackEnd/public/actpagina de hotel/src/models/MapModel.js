/**
 * MapModel.js
 * Modelo de datos y lógica de mapas Leaflet/OpenStreetMap
 */
const MapModel = {
  // Configuración
  config: {
    defaultZoom: 15,
    mapHeight: '500px', // Mapa grande y cuadrado
    tileLayer: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; OpenStreetMap contributors'
  },

  // Geocoding usando Nominatim (cacheado)
  cache: {},
  
  geocode: async function(address) {
    if (this.cache[address]) {
      console.log('[MapModel] Cache hit:', address);
      return this.cache[address];
    }
    
    const url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(address);
    try {
      const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
      if (!res.ok) throw new Error('Geocoding failed: ' + res.status);
      const data = await res.json();
      if (!data || !data[0]) return null;
      
      const result = { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
      this.cache[address] = result;
      console.log('[MapModel] Geocoded:', address, result);
      return result;
    } catch(err) {
      console.error('[MapModel] Geocoding error:', address, err);
      return null;
    }
  },

  // Validar que Leaflet esté disponible
  isLeafletAvailable: function() {
    return typeof L !== 'undefined';
  },

  // Obtener posición (lat/lng o por geocoding)
  getPosition: async function(latAttr, lngAttr, addressAttr) {
    if (latAttr && lngAttr) {
      return { lat: parseFloat(latAttr), lon: parseFloat(lngAttr) };
    }
    if (addressAttr) {
      return await this.geocode(addressAttr);
    }
    return null;
  },

  // Log de integridad
  log: function(msg) {
    if (window.DEBUG_MVC) console.log('[MapModel]', msg);
  }
};

// Verificación de carga
if (window.DEBUG_MVC) {
  console.log('[MapModel] Cargado exitosamente');
  console.log('[MapModel] Leaflet disponible:', MapModel.isLeafletAvailable());
}
