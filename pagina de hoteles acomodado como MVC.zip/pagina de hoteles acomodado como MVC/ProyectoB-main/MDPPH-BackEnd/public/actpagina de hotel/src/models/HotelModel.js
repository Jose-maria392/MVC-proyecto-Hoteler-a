/**
 * HotelModel.js
 * Modelo de datos de hoteles y paquetes
 */
const HotelModel = {
  // Base de datos de hoteles y paquetes
  hotels: {
    'hotel_uno': {
      id: 'hotel_uno',
      name: 'La Montaña Mágica',
      address: 'Av. P.º de la Reforma 64, Juárez, Cuauhtémoc, 06600 Ciudad de México',
      lat: 19.4326,
      lng: -99.1332,
      rating: 4
    },
    'hotel_dos': {
      id: 'hotel_dos',
      name: 'Hotel La Palmera Dorada',
      address: 'Av. México No.80, Peñón de los Baños, Venustiano Carranza, 15520',
      lat: 19.4089,
      lng: -99.0844,
      rating: 4
    },
    'hotel_tres': {
      id: 'hotel_tres',
      name: 'El Paraíso Perdido',
      address: 'Av Costera Miguel Alemán 163, Fracc Magallanes, Magallanes, 39670 Acapulco de Juárez, Gro',
      lat: 16.8530,
      lng: -99.8232,
      rating: 5
    }
  },

  packages: {
    'paquete_uno': {
      id: 'paquete_uno',
      name: 'La Montaña Mágica',
      address: 'Av. P.º de la Reforma 64, Juárez, Cuauhtémoc, 06600 Ciudad de México',
      lat: 19.4326,
      lng: -99.1332,
      rating: 4
    },
    'paquete_dos': {
      id: 'paquete_dos',
      name: 'Hotel La Palmera Dorada',
      address: 'Av. México No.80, Peñón de los Baños, Venustiano Carranza, 15520',
      lat: 19.4089,
      lng: -99.0844,
      rating: 4
    },
    'paquete_tres': {
      id: 'paquete_tres',
      name: 'El Paraíso Perdido',
      address: 'Av Costera Miguel Alemán 163, Fracc Magallanes, Magallanes, 39670 Acapulco de Juárez, Gro',
      lat: 16.8530,
      lng: -99.8232,
      rating: 5
    }
  },

  // Obtener hotel por ID
  getHotel: function(id) {
    return this.hotels[id] || null;
  },

  // Obtener paquete por ID
  getPackage: function(id) {
    return this.packages[id] || null;
  },

  // Obtener todos los hoteles
  getAllHotels: function() {
    return Object.values(this.hotels);
  },

  // Obtener todos los paquetes
  getAllPackages: function() {
    return Object.values(this.packages);
  },

  // Validar datos
  validate: function() {
    const errors = [];
    
    // Verificar hoteles
    Object.keys(this.hotels).forEach(key => {
      const hotel = this.hotels[key];
      if (!hotel.lat || !hotel.lng) errors.push(`Hotel ${key} sin coordenadas`);
      if (!hotel.name) errors.push(`Hotel ${key} sin nombre`);
    });

    // Verificar paquetes
    Object.keys(this.packages).forEach(key => {
      const pkg = this.packages[key];
      if (!pkg.lat || !pkg.lng) errors.push(`Paquete ${key} sin coordenadas`);
      if (!pkg.name) errors.push(`Paquete ${key} sin nombre`);
    });

    return { valid: errors.length === 0, errors };
  }
};

// Verificación de carga
if (window.DEBUG_MVC) {
  console.log('[HotelModel] Cargado exitosamente');
  const validation = HotelModel.validate();
  console.log('[HotelModel] Validación:', validation);
}
