/**
 * app.js
 * Inicializador de la aplicación MVC
 */

// Flag para debugging
window.DEBUG_MVC = true;

const App = {
  version: '1.0.0',
  initialized: false,

  // Inicializar la aplicación
  init: function() {
    console.log('%c[App] Inicializando...', 'color: #2196F3; font-weight: bold;');

    // Verificar integridad de modelos
    this.checkIntegrity();

    // Inicializar módulos (el orden es importante)
    if (typeof MapModel !== 'undefined') {
      console.log('[App] MapModel disponible');
    }
    
    if (typeof HotelModel !== 'undefined') {
      console.log('[App] HotelModel disponible');
    }

    if (typeof MapViewController !== 'undefined') {
      console.log('[App] MapViewController disponible');
    }

    if (typeof ModalController !== 'undefined') {
      console.log('[App] ModalController disponible');
    }

    this.initialized = true;
    console.log('%c[App] ✓ Inicialización completada', 'color: #4CAF50; font-weight: bold;');
  },

  // Chequeo de integridad
  checkIntegrity: function() {
    const checks = {
      'Leaflet disponible': typeof L !== 'undefined',
      'MapModel cargado': typeof MapModel !== 'undefined',
      'HotelModel cargado': typeof HotelModel !== 'undefined',
      'MapViewController cargado': typeof MapViewController !== 'undefined',
      'ModalController cargado': typeof ModalController !== 'undefined',
      'DOM ready': document.readyState !== 'loading'
    };

    console.log('%c[App] Chequeo de integridad:', 'color: #FF9800; font-weight: bold;');
    
    let allOk = true;
    Object.entries(checks).forEach(([name, status]) => {
      const icon = status ? '✓' : '✗';
      const color = status ? '#4CAF50' : '#F44336';
      console.log(`  %c${icon} ${name}`, `color: ${color}`);
      if (!status) allOk = false;
    });

    if (allOk) {
      console.log('%c[App] ✓ Todos los chequeos pasaron', 'color: #4CAF50; font-weight: bold;');
    } else {
      console.warn('%c[App] ⚠ Algunos chequeos fallaron', 'color: #F44336; font-weight: bold;');
    }

    return allOk;
  },

  // Obtener estado
  getStatus: function() {
    return {
      version: this.version,
      initialized: this.initialized,
      timestamp: new Date().toISOString()
    };
  }
};

// Inicializar en DOMContentLoaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => App.init());
} else {
  App.init();
}

// Exponer globalmente para debugging
window.App = App;

console.log('%c[App] Sistema MVC cargado', 'color: #2196F3; font-weight: bold; font-size: 14px;');
