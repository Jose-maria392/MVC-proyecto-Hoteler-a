/**
 * ModalController.js
 * Controlador de ventanas modales de reservación
 */
const ModalController = {
  currentModal: null,
  confirmModal: null,

  // Inicializar modales
  init: function() {
    this.currentModal = document.getElementById('miModal');
    this.confirmModal = document.getElementById('custom-modal');
    
    if (!this.currentModal || !this.confirmModal) {
      console.warn('[ModalController] No se encontraron elementos modales');
      return;
    }

    // Llevar modales al frente
    this.bringToFront(this.currentModal);
    this.bringToFront(this.confirmModal);

    this.setupEventListeners();
    console.log('[ModalController] Inicializado');
  },

  // Llevar modal al frente (z-index)
  bringToFront: function(modal) {
    modal.style.zIndex = 10000;
    const allModals = document.querySelectorAll('.modal');
    allModals.forEach(m => m.style.zIndex = 9999);
    modal.style.zIndex = 10000;
  },

  // Abrir modal de reservación
  openModal: function(e) {
    if (e) e.preventDefault();
    if (ModalController.currentModal) {
      ModalController.currentModal.style.display = 'block';
      ModalController.bringToFront(ModalController.currentModal);
      console.log('[ModalController] Modal abierto');
    }
  },

  // Cerrar modal de reservación
  closeModal: function() {
    if (ModalController.currentModal) {
      ModalController.currentModal.style.display = 'none';
      console.log('[ModalController] Modal cerrado');
    }
  },

  // Abrir modal de confirmación
  openConfirmModal: function(mensaje) {
    if (ModalController.confirmModal) {
      const msgEl = ModalController.confirmModal.querySelector('#modal-message');
      if (msgEl) msgEl.textContent = mensaje;
      ModalController.confirmModal.style.display = 'block';
      ModalController.bringToFront(ModalController.confirmModal);
      console.log('[ModalController] Confirmación modal abierto');
    }
  },

  // Cerrar modal de confirmación
  closeConfirmModal: function() {
    if (ModalController.confirmModal) {
      ModalController.confirmModal.style.display = 'none';
      console.log('[ModalController] Confirmación modal cerrado');
    }
  },

  // Obtener datos del formulario modal
  getFormData: function() {
    const form = this.currentModal?.querySelector('form') || {};
    return {
      nombre: document.getElementById('nombreHuesped')?.value || '',
      integrantes: document.getElementById('integrantes')?.value || '',
      cantidad: document.getElementById('cantidadOtro')?.value || '',
      fecha: document.getElementById('fechaReservacion')?.value || ''
    };
  },

  // Limpiar formulario modal
  clearForm: function() {
    const inputs = this.currentModal?.querySelectorAll('input, select') || [];
    inputs.forEach(input => {
      if (input.type === 'date') input.value = '';
      else if (input.type === 'number') input.value = '';
      else input.value = '';
    });
    console.log('[ModalController] Formulario limpiado');
  },

  // Setup de event listeners
  setupEventListeners: function() {
    // Botón "Reservar" principal
    const openBtns = document.querySelectorAll('#abrirModalBtn');
    openBtns.forEach(btn => btn.addEventListener('click', (e) => this.openModal(e)));

    // Botón "Cancelar"
    const cancelBtn = document.getElementById('cancelarBtn');
    if (cancelBtn) cancelBtn.addEventListener('click', () => this.closeModal());

    // Botón "Reservar Ahora"
    const reserveBtn = document.getElementById('reservarAhoraBtn');
    if (reserveBtn) {
      reserveBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const data = this.getFormData();
        const msg = `Reservación confirmada:\\nNombre: ${data.nombre}\\nIntegrantes: ${data.integrantes}\\nFecha: ${data.fecha}`;
        this.openConfirmModal(msg);
        this.closeModal();
        this.clearForm();
      });
    }

    // Botón cerrar confirmación
    const closeBtn = document.getElementById('close-modal-btn');
    if (closeBtn) closeBtn.addEventListener('click', () => this.closeConfirmModal());

    // Cerrar modales al hacer clic fuera
    window.addEventListener('click', (e) => {
      if (e.target === this.currentModal) this.closeModal();
      if (e.target === this.confirmModal) this.closeConfirmModal();
    });

    console.log('[ModalController] Event listeners configurados');
  }
};

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => ModalController.init());
} else {
  ModalController.init();
}

if (window.DEBUG_MVC) {
  console.log('[ModalController] Cargado exitosamente');
}
