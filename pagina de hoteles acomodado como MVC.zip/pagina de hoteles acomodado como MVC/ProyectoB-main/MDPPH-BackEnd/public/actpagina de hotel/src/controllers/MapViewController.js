/**
 * MapViewController.js
 * Controlador de vistas de mapas
 */
const MapViewController = {
  maps: {}, // Almacena instancias de mapas creadas

  // Crear un mapa en un contenedor
  createMap: function(container, lat, lon, zoom) {
    if (!MapModel.isLeafletAvailable()) {
      console.error('[MapViewController] Leaflet no disponible');
      return null;
    }

    zoom = zoom || MapModel.config.defaultZoom;
    if (!container.style.height) container.style.height = MapModel.config.mapHeight;

    const map = L.map(container).setView([lat, lon], zoom);
    
    L.tileLayer(MapModel.config.tileLayer, {
      maxZoom: 19,
      attribution: MapModel.config.attribution
    }).addTo(map);

    L.marker([lat, lon]).addTo(map);
    
    // Asegurar que el mapa render correctamente
    setTimeout(function() { 
      map.invalidateSize && map.invalidateSize(); 
    }, 200);

    console.log('[MapViewController] Mapa creado:', { lat, lon, zoom });
    return map;
  },

  // Inicializar todos los mapas en la página
  initMaps: async function() {
    const nodes = document.querySelectorAll('.osm-map');
    console.log('[MapViewController] Encontrados', nodes.length, 'contenedores .osm-map');

    for (const node of nodes) {
      const latAttr = node.getAttribute('data-lat');
      const lngAttr = node.getAttribute('data-lng');
      const addressAttr = node.getAttribute('data-address');
      const zoomAttr = parseInt(node.getAttribute('data-zoom') || '15', 10);

      const pos = await MapModel.getPosition(latAttr, lngAttr, addressAttr);
      
      if (pos) {
        const map = this.createMap(node, pos.lat, pos.lon, zoomAttr);
        this.maps[node.id || 'map_' + Object.keys(this.maps).length] = map;
      } else {
        console.warn('[MapViewController] No se pudo obtener posición para:', addressAttr);
      }
    }
  }
};

// Inicializar cuando el documento esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => MapViewController.initMaps());
} else {
  MapViewController.initMaps();
}

if (window.DEBUG_MVC) {
  console.log('[MapViewController] Cargado exitosamente');
}
