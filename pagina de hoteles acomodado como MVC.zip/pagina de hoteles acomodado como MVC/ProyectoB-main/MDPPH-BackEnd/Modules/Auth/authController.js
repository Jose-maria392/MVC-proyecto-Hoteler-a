const User = require('../../Models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Controller to handle user registration
exports.register = async (req, res) => {
    try {
        // Extract name, email and password from request body
        const { nombre, email, password } = req.body;

        // Validate that all required fields are present
        if (!nombre || !email || !password) {
            return res.status(400).json({ message: 'Todos los campos son requeridos.' });
        }

        // Check if a user with the provided email already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'El email ya está registrado.' });
        }

        // Hash the password securely before saving
        const hashedPassword = await bcrypt.hash(password, 10);

        // LOG DE SEGURIDAD: Muestra el hash generado
        console.log(`[PROTOCOLO REGISTRO] Email: ${email} -> HASH generado: ${hashedPassword.substring(0, 30)}...`);

        // Create a new user instance and save it to the database
        const newUser = new User({ nombre, email, password: hashedPassword });
        await newUser.save();

        // Respond with success message after successful registration
        res.status(201).json({ message: 'Usuario registrado exitosamente.' });
    } catch (error) {
        // Log error and send generic server error response
        console.error(error);
        res.status(500).json({ message: 'Error al registrar usuario.' });
    }
};

// Controller to handle user login authentication
exports.login = async (req, res) => {
    try {

        // Verificación inicial: si no hay body, devolver error 400
        if (!req.body) {
            return res.status(400).json({ message: 'Body de la solicitud requerido.' });
        }

        // ESTA DEBE SER LA PRIMERA LÍNEA EJECUTABLE DEL BLOQUE try
        const { email, password } = req.body;

        // 1. Verificación de campos faltantes (Ahora usa las variables extraídas)
        if (!email || !password) {
            return res.status(400).json({ message: 'Email y password requeridos.' });
        }

        // 2. Verificación de existencia de usuario
        const user = await User.findOne({ email });

        if (!user) {
            // LOG DE SEGURIDAD: Fallo por usuario no encontrado
            console.log(`[PROTOCOLO LOGIN] Intento fallido: Email no encontrado: ${email}`);
            return res.status(401).json({ message: 'Usuario o contraseña incorrectos.' });
        }

        // 3. Comparación de contraseña (bcrypt)
        const isMatch = await bcrypt.compare(password, user.password);
        
        // LOG DE SEGURIDAD: Muestra el resultado de la comparación bcrypt
        console.log(`[PROTOCOLO LOGIN] Email: ${email} -> Comparación de contraseña (bcrypt): ${isMatch}`);



        // Extract email and password from request body
        //const { email, password } = req.body;

        /*
        // Validate that both email and password are provided
        if (!email || !password) {
            return res.status(400).json({ message: 'Email y password requeridos.' });
        }*/

        // Find user by email in the database
        //const user = await User.findOne({ email });

        // If password does not match
        if (!isMatch) {
            return res.status(401).json({ message: 'Usuario o contraseña incorrectos.' });
        }

        // If user not found or password does not match, respond with invalid credentials
        /*if (!user || !(await user.comparePassword(password))) {
            return res.status(401).json({ message: 'Usuario o contraseña incorrectos.' });
        }*/

        // Generate a JWT token with user ID as payload, valid for 1 hour
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        // LOG DE SEGURIDAD: Muestra el token generado
        console.log(`[PROTOCOLO LOGIN] ID ${user._id} -> JWT generado: ${token.substring(0, 30)}...`);

        // Respond with success message, token, and user info
        res.json({ message: 'Login exitoso.', token, user: { id: user._id, nombre: user.nombre, email: user.email } });
    } catch (error) {
        // Log error and send generic server error response
        console.error(error);
        res.status(500).json({ message: 'Error al iniciar sesión.' });
    }
};

exports.forgotPassword = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({ message: 'No existe un usuario con ese correo.' });
        }

        // Generar código de 4 dígitos
        const code = Math.floor(1000 + Math.random() * 9000).toString();
        
        // Guardar en el usuario con expiración de 15 min
        user.resetCode = code;
        user.resetExpires = Date.now() + 15 * 60 * 1000;
        await user.save();

        // NOTA: Aquí es donde enviarías el correo con Nodemailer. 
        // Por ahora, el backend responde éxito.
        res.json({ message: 'Código de recuperación generado correctamente.' });
    } catch (error) {
        res.status(500).json({ message: 'Error en el servidor al solicitar recuperación.' });
    }
};

exports.verifyCode = async (req, res) => {
    try {
        const { email, code } = req.body;

        // Buscar usuario que tenga ese email, ese código y que no haya expirado
        const user = await User.findOne({ 
            email, 
            resetCode: code, 
            resetExpires: { $gt: Date.now() } 
        });

        if (!user) {
            return res.status(400).json({ message: 'Código inválido o expirado.' });
        }

        // Limpiar campos de recuperación después de usar el código
        user.resetCode = undefined;
        user.resetExpires = undefined;
        await user.save();

        // Generar token automático para iniciar sesión tras recuperar
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.json({ 
            message: 'Código verificado con éxito.', 
            token, 
            user: { id: user._id, nombre: user.nombre, email: user.email } 
        });
    } catch (error) {
        res.status(500).json({ message: 'Error al verificar el código.' });
    }
};