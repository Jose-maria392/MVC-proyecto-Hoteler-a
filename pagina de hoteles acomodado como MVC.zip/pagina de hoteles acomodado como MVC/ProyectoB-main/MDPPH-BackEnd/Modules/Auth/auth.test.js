const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../Server'); // Assuming Server.js exports app; if not, we need to refactor for testability
const setup = require('../../tests/setup');

let server;

beforeAll(async () => {
  // ⚠️ NUEVO PASO: Cierra cualquier conexión previa antes de conectar el servidor de prueba.
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
  }

  await setup.connect(); // Esto vuelve a llamar a mongoose.connect(uri)
  // Start express server for tests
  server = app.listen(0);
}, 60000);

afterAll(async () => {
  if (server) {
    server.close();
  }
  // 2. Cierra la base de datos de pruebas (llama a setup.js)
  await setup.closeDatabase();

  // 3. Opcional: Desconectar Mongoose si quedó alguna conexión abierta.
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
  }
}, 60000);

beforeEach(async () => {
  await setup.clearDatabase();
});

describe('Auth API Endpoints', () => {

  describe('POST /api/auth/register', () => {
    it('should register a new user successfully', async () => {
      const res = await request(server)
        .post('/api/auth/register')
        .send({
          nombre: 'Test User',
          email: 'testuser@example.com',
          password: 'password123'
        });
      expect(res.statusCode).toEqual(201);
      expect(res.body.message).toBe('Usuario registrado exitosamente.');
    });

    it('should fail if required fields are missing', async () => {
      const res = await request(server)
        .post('/api/auth/register')
        .send({ email: 'testuser@example.com', password: 'password123' });
      expect(res.statusCode).toEqual(400);
      expect(res.body.errors || res.body.message).toBeDefined();
    });

    it('should fail if email is already registered', async () => {
      // First registration
      await request(server)
        .post('/api/auth/register')
        .send({ nombre: 'Test User', email: 'testuser@example.com', password: 'password123' });

      // Duplicate registration
      const res = await request(server)
        .post('/api/auth/register')
        .send({ nombre: 'Test User2', email: 'testuser@example.com', password: 'password456' });
      expect(res.statusCode).toEqual(400);
      expect(res.body.message).toBe('El email ya está registrado.');
    });
  });

  describe('POST /api/auth/login', () => {
    beforeEach(async () => {
      // Register a user for login tests
      await request(server)
        .post('/api/auth/register')
        .send({
          nombre: 'Login User',
          email: 'loginuser@example.com',
          password: 'password123'
        });
    });

    it('should login successfully with valid credentials', async () => {
      const res = await request(server)
        .post('/api/auth/login')
        .send({
          email: 'loginuser@example.com',
          password: 'password123'
        });
      expect(res.statusCode).toEqual(200);
      expect(res.body.message).toBe('Login exitoso.');
      expect(res.body.token).toBeDefined();
      expect(res.body.user.email).toBe('loginuser@example.com');
    });

    it('should fail login with invalid password', async () => {
      const res = await request(server)
        .post('/api/auth/login')
        .send({
          email: 'loginuser@example.com',
          password: 'wrongpassword'
        });
      expect(res.statusCode).toEqual(401);
      expect(res.body.message).toBe('Usuario o contraseña incorrectos.');
    });

    it('should fail login with non-existing email', async () => {
      const res = await request(server)
        .post('/api/auth/login')
        .send({
          email: 'nonexistent@example.com',
          password: 'password123'
        });
      expect(res.statusCode).toEqual(401);
      expect(res.body.message).toBe('Usuario o contraseña incorrectos.');
    });

    it('should fail login if fields are missing', async () => {
      const res = await request(server)
        .post('/api/auth/login')
        .send({
          email: 'loginuser@example.com'
        });
      expect(res.statusCode).toEqual(400);
      expect(res.body.message).toBe('Email y password requeridos.');
    });
  });
});
