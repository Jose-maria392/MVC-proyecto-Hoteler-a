const express = require('express');
const router = express.Router();
const authController = require('./authController');

// IMPORTA LAS LIBRERÍAS DE SEGURIDAD
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');

// Limitar intentos de login
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,    // 15 minutos
  max: 5,                      // máximo 5 intentos por IP
  message: 'Demasiados intentos, espera unos minutos antes de intentar de nuevo.'
});

// Limitar intentos de registro
const registerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,    // 15 minutos
  max: 5,                      // máximo 5 intentos por IP
  message: 'Demasiados intentos de registro, espera unos minutos antes de intentar de nuevo.'
});

// Limitador específico para recuperación
const recoverLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 5, // solo 5 intentos de recuperación por minutos
  message: 'Demasiados intentos de recuperación, intenta más tarde.'
});

// RUTA DE REGISTRO con validación y rate limiting
router.post('/register', registerLimiter, [
  body('nombre').notEmpty().withMessage('Nombre requerido'),
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 6 }).withMessage('Password mínimo 6 caracteres')
], (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    // Devuelve errores de validación
    return res.status(400).json({ errors: errors.array() });
  }
  authController.register(req, res, next);
});

// RUTA DE LOGIN con validación y rate limiting
router.post('/login', loginLimiter, (req, res, next) => {
  // Sin validación aquí: deja que el controller maneje la verificación de campos
  authController.login(req, res, next);
});

// Ruta para solicitar el código (Paso 1 del modal)
router.post('/forgot-password', recoverLimiter, authController.forgotPassword);

// Ruta para verificar el código (Paso 2 del modal)
router.post('/verify-code', authController.verifyCode);

module.exports = router;
