document.querySelectorAll('.carousel-container').forEach((container) => {
  const carousel = container.querySelector('.carousel');
  const prevBtn = container.querySelector('.carousel-button-left');
  const nextBtn = container.querySelector('.carousel-button-right');

  const itemWidth = 280 + 20;

  prevBtn.addEventListener('click', () => {
    carousel.scrollBy({
      left: -itemWidth,
      behavior: 'smooth'
    });
  });

  nextBtn.addEventListener('click', () => {
    carousel.scrollBy({
      left: itemWidth,
      behavior: 'smooth'
    });
  });
});
