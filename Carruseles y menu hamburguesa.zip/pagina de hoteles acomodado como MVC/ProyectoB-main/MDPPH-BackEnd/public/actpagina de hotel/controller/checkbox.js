// ----------------------------------
// 🌟 FUNCIONES PARA EL CHECKBOX DE PRIVACIDAD 🌟
// ----------------------------------

// Elementos del modal de privacidad
const privacidadModal = document.getElementById('privacidad-modal');
const verPrivacidadLink = document.getElementById('ver-privacidad');
const closePrivacidadModal = document.getElementById('close-privacidad-modal');
const aceptarPrivacidadBtn = document.getElementById('aceptar-privacidad-btn');
const privacidadCheckbox = document.getElementById('privacidad-checkbox');
const privacidadError = document.getElementById('privacidadError');
const crearCuentaBtn = document.getElementById('crear-cuenta-btn');

// Función para abrir el modal de privacidad
function abrirModalPrivacidad() {
    if (privacidadModal) {
        privacidadModal.style.display = 'flex';
        privacidadModal.setAttribute('aria-hidden', 'false');
        document.getElementById('privacidadModalContent').focus();
    }
}

// Función para cerrar el modal de privacidad
function cerrarModalPrivacidad() {
    if (privacidadModal) {
        privacidadModal.style.display = 'none';
        privacidadModal.setAttribute('aria-hidden', 'true');
    }
}

// Función para aceptar privacidad (marcar checkbox)
function aceptarPrivacidad() {
    if (privacidadCheckbox) {
        privacidadCheckbox.checked = true;
        cerrarModalPrivacidad();
        if (privacidadError) {
            privacidadError.style.display = 'none';
        }
    }
}

// Event Listeners para el modal de privacidad
if (verPrivacidadLink) {
    verPrivacidadLink.addEventListener('click', function(e) {
        e.preventDefault();
        abrirModalPrivacidad();
    });
}

if (closePrivacidadModal) {
    closePrivacidadModal.addEventListener('click', cerrarModalPrivacidad);
}

if (aceptarPrivacidadBtn) {
    aceptarPrivacidadBtn.addEventListener('click', aceptarPrivacidad);
}

// Event Listener para el checkbox (cuando se marca manualmente)
if (privacidadCheckbox) {
    privacidadCheckbox.addEventListener('change', function() {
        if (this.checked) {
            if (privacidadError) {
                privacidadError.style.display = 'none';
            }
        }
    });
}

// Validación del checkbox en el formulario de registro
if (crearCuentaBtn) {
    const registerForm = document.getElementById('registerForm');
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            // Verificar si el checkbox está marcado
            if (!privacidadCheckbox || !privacidadCheckbox.checked) {
                e.preventDefault();
                
                // Mostrar error
                if (privacidadError) {
                    privacidadError.style.display = 'block';
                }
                
                // Enfocar el checkbox
                privacidadCheckbox.focus();
                
                return false;
            }
        });
    }
}

// Cerrar modal de privacidad si se hace clic fuera del contenido
if (privacidadModal) {
    privacidadModal.addEventListener('click', function(e) {
        if (e.target === privacidadModal) {
            cerrarModalPrivacidad();
        }
    });
}

// Cerrar modal con la tecla Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && privacidadModal && privacidadModal.style.display === 'flex') {
        cerrarModalPrivacidad();
    }
});